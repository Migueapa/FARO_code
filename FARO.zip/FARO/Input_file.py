# coding=utf-8

import numpy as np
import Modules.Change_control.Basic_prog.Functions as fun

def Inp_dat():

	######### Name #########

	name = 'JPAS'

	######### Observables #########

	#'C' ---> Multitracer power spectrum
	#'L' ---> Convergence power spectrum
	#'C_L_C' ---> Multitracer + Convergence + Cross-correlated power spectra

	do = 'C_L_C'

	######### Fiducial model #########

	Omegam = 0.31
	gamma=0.545
	h=0.68 
	omegab=0.0226 
	ns=0.96
	s8=0.82

	######### Redshift bins and fraction of the sky #########

	z = np.array([0.3, 0.5, 0.7, 0.9, 1.1, 1.3])
	zb = np.concatenate(([z[0]-(z[1]-z[0])/2], z+(z[1]-z[0])/2))

	deg=8500
	fsky = deg*(2.424073094*10**-5)

        ######### ln(k) bins #########

	N = 10
	lnkb = np.linspace(np.log(0.007), np.log(1.),N+1)
	dif = lnkb[1] - lnkb[0]
	lnk = lnkb + dif/2.
	lnk = lnk[0:N]

	######### Clustering data #########

	S0 = 11.   #Units of Mpc/h

	bLRG, bELG, bQS, bELG_euclid, bBGS = fun.b_z( z, Omegam, gamma )

	nLRG = np.array([2.26575, 1.56325, 0.688, 0.11975, 0.009, 0.])*10**-3
	nELG = np.array([29.5855, 11.8113, 5.02125, 1.3795, 0.412, 0.06725])*10**-3
	nQS = np.array([0.454, 1.14, 1.61, 2.27, 2.86, 3.6])*10**-5

	dzLRG = 0.003
	dzELG = 0.003
	dzQS = 0.003

	b = np.array([bLRG, bELG, bQS])
	nb = np.array([nLRG, nELG, nQS])   #Units of (h/Mpc)^3
	dzC = np.array([dzLRG, dzELG, dzQS])
	bias_names = np.array(['LRG', 'ELG', 'QS'])

	######### Lensing data #########

	gint = 0.22

	dzL = 0.03
	nt = 12.32    #Units of galaxies per square arc minute
	zm = 0.5

        arr = fun.P_class( h, Omegam, omegab, ns, s8 )
	return name, do, Omegam, gamma, h, omegab, ns, s8, arr, z, zb, lnk, lnkb, fsky, S0, b, nb, dzC, bias_names, gint, dzL, nt, zm
