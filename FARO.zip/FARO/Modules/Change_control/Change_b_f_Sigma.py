# coding=utf-8

import numpy as np
from math import *
import Basic_prog.Functions as fun

#Given the redshift bin centers "z" and bounds "zb", and fiducial values of "Omegam" and "gamma";
#this function computes the derivative "DDf" of D(z_i) respect to f(z_j) with structure: [i,j].

def DDf_z( z, zb, Omegam, gamma ):
    D = fun.D_z( z, Omegam, gamma )
    dza = np.diff(zb)
    DDf = np.zeros((np.size(z),np.size(z)))
    for j in np.arange(0,np.size(z)):
        for i in np.arange(0,np.size(z)):
	    if j>i:
                DDf[i][j] = 0.
            elif i>=j:
                DDf[i][j] = -((D[i]*dza[j])/(1.+z[j]))
            


    return DDf

##### Clustering change of variable #####
#This function computes the change of variable: [A_i^{a},R_i,E_i] - - > [b_i^{a},f_i,E_i]

def Deriv_clustering( z, zb, b, Omegam, gamma, s8 ):
    f = fun.f_z( z, Omegam, gamma )
    D = fun.D_z( z, Omegam, gamma )
    A = fun.A_z( z, b, Omegam, gamma, s8 )
    DDf = DDf_z( z, zb, Omegam, gamma )
    z_size = np.size(z)
    b_size = np.size(b)/np.size(z)
    Ident_z = np.eye(z_size)
    zeros_z = np.zeros((z_size,z_size))
    Ident_b = np.eye(b_size)
    Vi_b = np.ones(b_size)
    DADA = np.einsum('i,ij,ab->ijab',s8*D,Ident_z,Ident_b)
    DADR = np.einsum('ai,i,ij->ija',A,1./D,DDf)
    DADE = np.einsum('ij,a->ija',zeros_z,Vi_b)
    DRDA = np.einsum('ij,b->ijb',zeros_z,Vi_b)
    DRDR = np.einsum('i,ij->ij',s8*D,Ident_z) + np.einsum('i,ij->ij',s8*f,DDf)
    DRDE = np.einsum('ij->ij',zeros_z)
    DEDA = np.einsum('ij,b->ijb',zeros_z,Vi_b)
    DEDR = np.einsum('ij->ij',zeros_z)
    DEDE = np.einsum('ij->ij',Ident_z)
    return DADA, DADR, DADE, DRDA, DRDR, DRDE, DEDA, DEDR, DEDE

##### Lensing change of variable #####
#This function computes the change of variable: [E_i,L_i] - - > [E_i,\Sigma_i]

def Deriv_lensing( z, Omegam, gamma, s8 ):
    L = fun.L_z( z, Omegam, gamma, s8 )
    z_size = np.size(z)
    Ident_z = np.eye(z_size)
    zeros_z = np.zeros((z_size,z_size))
    DEDE = np.einsum('ij->ij',Ident_z)
    DEDL = np.einsum('ij->ij',zeros_z)
    DLDE = np.einsum('ij->ij',zeros_z)
    DLDL = np.einsum('i,ij->ij',L,Ident_z)
    return DEDE, DEDL, DLDE, DLDL

##### Clustering + Lensing change of variable #####
#This function computes the change of variable [A_i^{a},R_i,L_i,E_i] - - > [b_i^{a},f_i,\Sigma_i,E_i]

def Deriv_clust_lens( z, zb, b, Omegam, gamma, s8 ):
    f = fun.f_z( z, Omegam, gamma )
    D = fun.D_z( z, Omegam, gamma )
    A = fun.A_z( z, b, Omegam, gamma, s8 )
    DDf = DDf_z( z, zb, Omegam, gamma )
    L = fun.L_z( z, Omegam, gamma, s8 )
    z_size = np.size(z)
    b_size = np.size(b)/np.size(z)
    Ident_z = np.eye(z_size)
    zeros_z = np.zeros((z_size,z_size))
    Ident_b = np.eye(b_size)
    Vi_b = np.ones(b_size)
    DADA = np.einsum('i,ij,ab->ijab',s8*D,Ident_z,Ident_b)
    DADR = np.einsum('ai,i,ij->ija',A,1./D,DDf)
    DADL = np.einsum('ij,a->ija',zeros_z,Vi_b)
    DADE = np.einsum('ij,a->ija',zeros_z,Vi_b)
    DRDA = np.einsum('ij,b->ijb',zeros_z,Vi_b)
    DRDR = np.einsum('i,ij->ij',s8*D,Ident_z) + np.einsum('i,ij->ij',s8*f,DDf)
    DRDL = np.einsum('ij->ij',zeros_z)
    DRDE = np.einsum('ij->ij',zeros_z)
    DLDA = np.einsum('ij,b->ijb',zeros_z,Vi_b)
    DLDR = np.einsum('i,ij->ij',L/D,DDf)
    DLDL = np.einsum('i,ij->ij',L,Ident_z)
    DLDE = np.einsum('ij->ij',zeros_z)
    DEDA = np.einsum('ij,b->ijb',zeros_z,Vi_b)
    DEDR = np.einsum('ij->ij',zeros_z)
    DEDL = np.einsum('ij->ij',zeros_z)
    DEDE = np.einsum('ij->ij',Ident_z)
    return DADA, DADR, DADL, DADE, DRDA, DRDR, DRDL, DRDE, DLDA, DLDR, DLDL, DLDE, DEDA, DEDR, DEDL, DEDE
