# coding=utf-8

#This module contains functions that compute the derivatives of the cluster, lensing and cross correlation power spectra
#respect to the parameters in each redshift bin: [A_i,R,E] for clustering y [E,L] for weak lensing and
# [A_i, L, E] for the cross correlation.

import numpy as np
from math import *
import Functions as fun
import Aux_fun as aux
import Win_dens as win

#This function computes the derivative of the multitracer power spectrum DP_{ij}(z_a,mu_b,k_c)/D\theta_p, the structure is- - -> [p,a,b,c,i,j]

def DPT_z_clustering( z, zb, b, mu, k, Kaiser, P, H0, Omegam, gamma, s8, lnk, lnkb, arr ):
    Dchi = aux.DchiE_z( z, zb, H0, Omegam )
    E = fun.E_z( z, Omegam )
    R = fun.R_z( z, Omegam, gamma, s8 )
    Chi = fun.Chi_z( z, H0, Omegam )
    z_size = np.size(z)
    mu_size = np.size(mu)
    k_size = np.size(k)
    b_size = np.size(b)/np.size(z)
    Ident_z = np.eye(z_size)
    Ident_b = np.eye(b_size)
    DlnP_param = fun.Deriv_lnP( k, lnk, lnkb, arr )
    dlnP_arr = aux.dlnP_fun( arr )
    dlnP = aux.lnP_k( k, dlnP_arr )
    num_param = np.size(DlnP_param)/np.size(k)
    DPGlob = np.einsum('pc,acbij->pabcij',DlnP_param,P)
    DPA = np.einsum('iab,li,ka,acbij->lkabcij',1./Kaiser,Ident_b,Ident_z,P) + np.einsum('jab,lj,ka,acbij->lkabcij',1./Kaiser,Ident_b,Ident_z,P)
    DPR = np.einsum('iab,b,ka,acbij->kabcij',1./Kaiser,mu**2.,Ident_z,P) + np.einsum('jab,b,ka,acbij->kabcij',1./Kaiser,mu**2.,Ident_z,P)
    T1 = np.einsum('ka,a->ka',Ident_z, 1./E) - 2.*np.einsum('a,ka->ka',1./(Chi), Dchi)
    T2 = np.einsum('ka,a->ka',Ident_z, 1./E) + np.einsum('a,ka->ka',1./(Chi), Dchi)
    T3 = np.einsum('iab,a,b,acbij->acbij',1./Kaiser,2.*R,(1.-mu**2.)*mu**2.,P) + np.einsum('jab,a,b,acbij->acbij',1./Kaiser,2.*R,(1.-mu**2.)*mu**2.,P)
    T4 = np.einsum('ka,a,b->kab',Ident_z, 1./E, mu**2.) - np.einsum('a,ka,b->kab',1./(Chi), Dchi, 1.-mu**2.)
    DPE = np.einsum('ka,acbij->kabcij',T1,P) + np.einsum('ka,acbij->kabcij',T2,T3) + np.einsum('kab,c,acbij->kabcij',T4,dlnP,P)
    DPT = np.zeros((num_param+z_size*(b_size + 2),z_size,mu_size,k_size,b_size,b_size))
    DPT[0:num_param] = DPGlob
    for i in np.arange(0,np.size(z)):
	for j in np.arange(0,b_size):
	    DPT[num_param+(b_size+2)*i+j] = DPA[j][i]

	DPT[num_param+(b_size+2)*i+b_size] = DPR[i]
	DPT[num_param+(b_size+2)*i+b_size+1] = DPE[i]


    return DPT

#This function computes the derivative of the convergence power spectrum DP_{ij}(\ell_a)/D\theta_p, the structure is - - -> [p,a,i,j]

def DPT_z_lensing( Pkka, l, lcut, z, zb, lnk, lnkb, arr, N0_cell, N1_cell, N2_cell, H0, Omegam, gamma, s8 ):
    n = np.size(lnk)-1
    E = fun.E_z( z, Omegam )
    g = win.g_z( N0_cell, N1_cell, z, Omegam, H0 )
    Dg = aux.DgE_z( N1_cell, N2_cell, z, zb, H0, Omegam )
    L = fun.L_z( z, Omegam, gamma, s8 )
    Chi = fun.Chi_z( z, H0, Omegam )
    dlnP_arr = aux.dlnP_fun( arr )
    dlnP = aux.dlnPf_z_l( l, z, H0, Omegam, dlnP_arr )
    Dchi = aux.DchiE_z( z, zb, H0, Omegam )
    Pr4 = - np.einsum('al,b,ab,lb,ijlb->alij',lcut, (1./Chi), Dchi, dlnP, Pkka)
    DlnP_param = fun.Deriv_lnP_lens( l, z, H0, Omegam, lnk, lnkb, arr )
    DPGlob = np.einsum('pla,ijla->plij',DlnP_param,Pkka)
    Pr1 = - np.einsum('al,a,ijla->alij',lcut,1./E,Pkka)
    Pr2 = np.einsum('al,ib,aib,ijlb->alij',lcut,1./(g+10**-10),Dg,Pkka)
    Pr3 = np.einsum('al,jb,ajb,ijlb->alij',lcut,1./(g+10**-10),Dg,Pkka)
    DPE = Pr1 + Pr2 + Pr3 + Pr4
    DPL = np.einsum('al,a,ijla->alij',lcut,2./L,Pkka)
    DPT = np.zeros((n+2*np.size(z),np.size(l),np.size(z),np.size(z)))
    DPT[0:n] = DPGlob
    for i in np.arange(0,np.size(z)):
	DPT[n+2*i] = DPE[i]
        DPT[n+2*i+1] = DPL[i]

    return DPT

#This function computes the derivative of the cross correlation power spectrum DP_{ij}^{alpha}(\ell_a)/D\theta_p, the structure is - - -> [p,i,j,alpha,a]

def DPT_z_clust_lens( Pkd, l, lcut, z, zb, b, lnk, lnkb, arr, N0_cell, N1_cell, N2_cell, H0, Omegam, gamma, s8 ):
    n = np.size(lnk)-1
    numl = np.size(l)
    b_size = np.size(b)/np.size(z)
    E = fun.E_z( z, Omegam )
    L = fun.L_z( z, Omegam, gamma, s8 )
    A = fun.A_z( z, b, Omegam, gamma, s8 )
    Chi = fun.Chi_z( z, H0, Omegam )
    g = win.g_z( N0_cell, N1_cell, z, Omegam, H0 )
    Dg = aux.DgE_z( N1_cell, N2_cell, z, zb, H0, Omegam )
    Dchi = aux.DchiE_z( z, zb, H0, Omegam )
    dlnP_arr = aux.dlnP_fun( arr )
    dlnP = aux.dlnPf_z_l( l, z, H0, Omegam, dlnP_arr )
    DlnP_param = fun.Deriv_lnP_lens( l, z, H0, Omegam, lnk, lnkb, arr )
    Pr1 = np.identity(np.size(z))
    Pr2 = np.identity(b_size)
    Pr3 = np.einsum('pl,ij,pij,ijal->pijal',lcut,1./(g+10**-10),Dg,Pkd)
    Pr4 = -np.einsum('pl,j,lj,pj,ijal->pijal',lcut,1./(Chi),(1.+dlnP),Dchi,Pkd)
    DPL = np.einsum('pl,p,pj,ijal->pijal',lcut,1./L,Pr1,Pkd)
    DPA = np.einsum('pl,pj,ab,bp,ijal->bpijal',lcut,Pr1,Pr2,1./A,Pkd)
    DPGlob = np.einsum('plj,ijal->pijal',DlnP_param,Pkd)
    DPE = Pr3 + Pr4
    DPT = np.zeros(((n+(b_size)+2)*np.size(z),np.size(z),np.size(z),b_size,numl))
    DPT[0:n] = DPGlob
    for i in np.arange(0,np.size(z)):
	for j in np.arange(0,b_size):
	    DPT[n+(b_size+2)*i+j] = DPA[j][i]

	DPT[n+(b_size+2)*i+b_size] = DPL[i]
	DPT[n+(b_size+2)*i+b_size+1] = DPE[i]


    return DPT
