# coding=utf-8

#This module contains the functions that compute the power spectra and the covariance matrices.

import numpy as np
from math import *
import Functions as fun
import Win_dens as win
import Aux_fun as aux

#This function computes the following:
#The multitracer power spectrum "P": P_ij (z_a, k_c, \hat{\mu}_b), the structure is - - > [a,c,b,i,j]
#The Kaiser term "Kaiser": (A_i(z_a)+R(z_a)*mu_b**2), the structure is - - > [i,a,b]
#The inverse of the covariance matrix for clustering "Cinv": C_{ij}^{-1} (z_a, k_c, mu_b), the structure is - - > [a,c,b,i,j]

def Clustering_P_Kai_C( z, dz, nb, b, k, mu, arr, H0, Omegam, gamma, s8 ):
    z_size = np.size(z)
    b_size = np.size(b)/np.size(z)
    mu_size = np.size(mu)
    k_size = np.size(k)
    A = fun.A_z( z, b, Omegam, gamma, s8 )
    R = fun.R_z( z, Omegam, gamma, s8 )
    E = fun.E_z( z, Omegam )
    P = aux.Pf_z_k( k, s8, arr )
    Ib = np.ones(b_size)
    Imu = np.ones(mu_size)
    Ik = np.ones(k_size)
    z_err = aux.err_z_factor( z, mu, k, b, dz, E, H0 )
    Kaiser = np.einsum('ia,b->iab', A, Imu) + np.einsum('i,a,b->iab', Ib, R, mu**2.)
    P = np.einsum('iab,jab,c,iabc,jabc->acbij', Kaiser, Kaiser, P, z_err, z_err )
    Ident_b = np.eye(b_size)
    C = P + np.einsum('c,b,ia,ij->acbij',Ik,Imu,1./(nb+10.**-20.),Ident_b)
    Cinv = np.zeros((np.size(z),np.size(k),np.size(mu),b_size,b_size))
    for a in np.arange(0,np.size(z)):
        for b in np.arange(0,np.size(mu)):
            for c in np.arange(0,np.size(k)):
		Cinv[a][c][b] = np.linalg.inv(C[a][c][b])



    return P, Kaiser, Cinv

#Now we define functions for three different cases: convergence, cross y convergence+cross.

#The following function computes:
#The convergence power spectrum "Pkk": P^{\kappa}_{ij} (\ell_a), the structure is - - > [a,i,j]
#The convergence power spectrum in a redshift bin z_b "Pkka": P^{\kappa}_{ij} (\ell_a, z_b), the structure is - - > [i,j,a,b]

def P_conv( l, z, zb, arr, N0_cell, N1_cell, H0, Omegam, gamma, s8 ):
    E = fun.E_z( z, Omegam )
    L = fun.L_z( z, Omegam, gamma, s8 )
    Pm = aux.Pf_z_l( l, z, H0, Omegam, s8, arr )
    g = win.g_z( N0_cell, N1_cell, z, Omegam, H0 )
    dza = np.diff(zb)
    Pr1 = ((9.*H0**3.)/(4.))*((dza*(1.+z)**2.)/(E))
    Pkk = np.einsum('a,ia,ja,a,la->lij',Pr1,g,g,L**2.,Pm)
    Pkka = np.einsum('a,ia,ja,a,la->ijla',Pr1,g,g,L**2.,Pm)
    return Pkk, Pkka

#The following function computes:
#The inverse of the covariance matrix for lensing "Cinv_kk": C_{ijpk}(\ell_a), the structure is - - > [a,i,j,p,k]

def C_inv_conv( Pkk, l, z, zb, gint, zm, nt ):
    Il = np.ones(np.size(l))
    nh = np.zeros(np.size(z))
    for i in np.arange(0,np.size(z)):
        zp = zm/1.412
        zint = np.linspace(zb[i],zb[i+1],20)
        nint = nt*((2*(zp**3)/3.)**-1)*(zint**2)*np.exp(-(zint/zp)**1.5)
        nh[i] = np.trapz(nint,zint)

    Pr1 = (gint**2.)/nh
    Pr2 = np.identity(np.size(z))
    Pkkh = Pkk + np.einsum('l,i,ij->lij',Il,Pr1,Pr2)
    C = np.einsum('lik,ljp->lijkp',Pkkh,Pkkh)+np.einsum('lip,ljk->lijpk',Pkkh,Pkkh)
    Cinv_kk = np.zeros((np.size(l),np.size(z),np.size(z),np.size(z),np.size(z)))
    for i in np.arange(0,np.size(l)):
        Cinv_kk[i] = np.linalg.tensorinv(C[i],ind=2)

    return Cinv_kk

#The following function computes:
#The convergence power spectrum "Pkk": P^{\kappa}_{ij} (\ell_a), the structure is - - > [i,j,a]
#The cross correlation power spectrum "Pkd": P_{ij}^{alpha}(\ell_a), the structure is - - > [i,j,alpha,a]
#The 2D density power spectrum "Pdd": P_{ij}^{alpha beta}(\ell_a), the structure is - - > [i,j,alpha,beta,a]

def P_cross( l, z, zb, b, arr, N0_cell, N1_cell, H0, Omegam, gamma, s8 ):
    E = fun.E_z( z, Omegam )
    L = fun.L_z( z, Omegam, gamma, s8 )
    Chi = fun.Chi_z( z, H0, Omegam )
    Pm = aux.Pf_z_l( l, z, H0, Omegam, s8, arr )
    A = fun.A_z( z, b, Omegam, gamma, s8 )
    g = win.g_z( N0_cell, N1_cell, z, Omegam, H0 )
    dza = np.diff(zb)
    Pr1 = ((9.*H0**3.)/(4.))*((dza*(1.+z)**2.)/(E))
    Pr2 = ((3.*H0**2.)/(2.))*(((1.+z))/(Chi))
    Pr3 = (H0*E)/(Chi**2.)
    Pr4 = np.identity(np.size(z))
    Pdd = np.einsum('ij,i,ai,bi,li->ijabl',Pr4,Pr3,A,A,Pm)
    Pkk = np.einsum('a,ia,ja,a,la->ijl',Pr1,g,g,L**2.,Pm)
    Pkd = np.einsum('ij,j,j,aj,lj->ijal',g,Pr2,L,A,Pm)
    return Pkk, Pkd, Pdd

#The following function computes:
#The inverse of the covariance matrix for the cross correlation "Cinv_cross": (C_{ijpk}^{ab})^{-1}(\ell_c), the structure is - - > [c,i,a,j,k,b,p]

def C_inv_cross( Pdd, Pkk, Pkd, l, z, zb, n2D, gint, zm, nt ):
    Il = np.ones(np.size(l))
    nh = np.zeros(np.size(z))
    for i in np.arange(0,np.size(z)):
        zp = zm/1.412
        zint = np.linspace(zb[i],zb[i+1],20)
        nint = nt*((2*(zp**3)/3.)**-1)*(zint**2)*np.exp(-(zint/zp)**1.5)
        nh[i] = np.trapz(nint,zint)

    Pr1 = (gint**2.)/nh
    Pr2 = 1./(n2D+10.**-20.)
    Pr3 = np.identity(np.size(z))
    Pr4 = np.identity(np.size(n2D)/np.size(z))
    Pddh = Pdd + np.einsum('l,ai,ij,ab->ijabl',Il,Pr2,Pr3,Pr4)
    Pkkh = Pkk + np.einsum('l,i,ij->ijl',Il,Pr1,Pr3)
    C = np.einsum('ikl,jpabl->liajkbp',Pkkh,Pddh)+np.einsum('ipbl,kjal->ljaipbk',Pkd,Pkd)
    Cinv_cross = np.zeros((np.size(l),np.size(z),np.size(n2D)/np.size(z),np.size(z),np.size(z),np.size(n2D)/np.size(z),np.size(z)))
    for i in np.arange(0,np.size(l)):
        Cinv_cross[i] = np.linalg.tensorinv(C[i], ind=3)

    return Cinv_cross

#Finally these two last functions compute the power spectra and inverse covariance matrices for
#lensing and the cross correlation in a combinated way.
#The convergence power spectrum "Pkk": P^{\kappa}_{ij} (\ell_a), the structure is - - > [i,j,a]
#The cross correlation power spectrum "Pkd": P_{ij}^{alpha}(\ell_a), the structure is - - > [i,j,alpha,a]
#The 2D density power spectrum "Pdd": P_{ij}^{alpha beta}(\ell_a), the structure is - - > [i,j,alpha,beta,a]
#The convergence power spectrum in a redshift bin z_b "Pkka": P^{\kappa}_{ij} (\ell_a, z_b), the structure is - - > [i,j,a,b]
#The inverse of the covariance matrix for lensing "Cinv_kk": C_{ijpk}(\ell_a), the structure is - - > [a,i,j,p,k]
#The inverse of the covariance matrix for the cross correlation "Cinv_cross": (C_{ijpk}^{ab})^{-1}(\ell_c), the structure is - - > [c,i,a,j,k,b,p]

def P_conv_cross( l, z, zb, b, arr, N0_cell, N1_cell, H0, Omegam, gamma, s8 ):
    E = fun.E_z( z, Omegam )
    L = fun.L_z( z, Omegam, gamma, s8 )
    Chi = fun.Chi_z( z, H0, Omegam )
    Pm = aux.Pf_z_l( l, z, H0, Omegam, s8, arr )
    A = fun.A_z( z, b, Omegam, gamma, s8 )
    g = win.g_z( N0_cell, N1_cell, z, Omegam, H0 )
    dza = np.diff(zb)
    Pr1 = ((9.*H0**3.)/(4.))*((dza*(1.+z)**2.)/(E))
    Pr2 = ((3.*H0**2.)/(2.))*(((1.+z))/(Chi))
    Pr3 = (H0*E)/(Chi**2.)
    Pr4 = np.identity(np.size(z))
    Pdd = np.einsum('ij,i,ai,bi,li->ijabl',Pr4,Pr3,A,A,Pm)
    Pkk = np.einsum('a,ia,ja,a,la->ijl',Pr1,g,g,L**2.,Pm)
    Pkd = np.einsum('ij,j,j,aj,lj->ijal',g,Pr2,L,A,Pm)
    Pkka = np.einsum('a,ia,ja,a,la->ijla',Pr1,g,g,L**2.,Pm)
    return Pkk, Pkd, Pdd, Pkka


def C_inv_conv_cross( Pdd, Pkk, Pkd, l, z, zb, n2D, gint, zm, nt ):
    Il = np.ones(np.size(l))
    nh = np.zeros(np.size(z))
    for i in np.arange(0,np.size(z)):
        zp = zm/1.412
        zint = np.linspace(zb[i],zb[i+1],20)
        nint = nt*((2*(zp**3)/3.)**-1)*(zint**2)*np.exp(-(zint/zp)**1.5)
        nh[i] = np.trapz(nint,zint)

    Pr1 = (gint**2.)/nh
    Pr2 = 1./(n2D+10.**-20.)
    Pr3 = np.identity(np.size(z))
    Pr4 = np.identity(np.size(n2D)/np.size(z))
    Pddh = Pdd + np.einsum('l,ai,ij,ab->ijabl',Il,Pr2,Pr3,Pr4)
    Pkkh = Pkk + np.einsum('l,i,ij->ijl',Il,Pr1,Pr3)
    C_cross = np.einsum('ikl,jpabl->liajkbp',Pkkh,Pddh)+np.einsum('ipbl,kjal->ljaipbk',Pkd,Pkd)
    Cinv_cross = np.zeros((np.size(l),np.size(z),np.size(n2D)/np.size(z),np.size(z),np.size(z),np.size(n2D)/np.size(z),np.size(z)))
    for i in np.arange(0,np.size(l)):
        Cinv_cross[i] = np.linalg.tensorinv(C_cross[i], ind=3)

    C_conv = np.einsum('ikl,jpl->lijkp',Pkkh,Pkkh)+np.einsum('ipl,jkl->lijpk',Pkkh,Pkkh)
    Cinv_kk = np.zeros((np.size(l),np.size(z),np.size(z),np.size(z),np.size(z)))
    for i in np.arange(0,np.size(l)):
        Cinv_kk[i] = np.linalg.tensorinv(C_conv[i],ind=2)

    return Cinv_kk, Cinv_cross
