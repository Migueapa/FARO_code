# coding=utf-8

#This module contains the functions needed to compute the redshift bin distributions for lensing.

import numpy as np
from math import *
import Functions as fun

#This function generates the galaxy distribution functions for each redshift bin.

def dens_function( z, zb, dz, zm ):
    zp = zm/1.412
    n_cell = np.zeros(np.size(z),dtype=object)
    z_cell = np.zeros(np.size(z),dtype=object)
    for i in np.arange(0,np.size(z)):
        eps = dz/10.
        zf = np.arange(0,2*zb[np.size(zb)-1],eps)
        n = np.zeros(np.size(zf))
        for j in np.arange(0, np.size(zf)):
            N2 = 100
            zint = np.linspace(zb[i],zb[i+1],N2)
            sigma = dz*(1.+z[i])
            nint = (zint**2.)*np.exp(-(zint/zp)**(3./2.))*np.exp(-((zint-zf[j])/(np.sqrt(2.)*sigma))**2.)
            n[j] = np.trapz(nint,zint)
        
        A = np.trapz(n,zf)
        n = n/A
        n_cell[i] = n
        z_cell[i] = zf
    
    return n_cell, z_cell

#This function evaluates the galaxy distribution functions in any z smoothly.

def n_i( i, z, z_cell, n_cell ):
    if np.size(z)==1:
        z=np.array([z])

    x = z_cell[i]
    y = n_cell[i]

    n_z = np.zeros(np.size(z))
    for j in np.arange(0,np.size(z)):
        k=z[j]
        if k>=x[np.size(x)-1]:
            n_z[j] = 0
        elif k<=x[0]:
            n_z[j] = 0
        else:
            I = np.argmin(abs(x-k*np.ones((1,np.size(x))))+10**-8)
            if I==np.size(x)-1:
                I-=1
                
            m = (y[I+1]-y[I])/(x[I+1]-x[I])
            n = y[I]-m*x[I]
            n_z[j] = n+m*k
            
        
    return n_z

#This function computes the integrals of the galaxy densities need for the computation.

def N_funct( z_cell, n_cell, zb, dz, z, Omegam, H0 ):
    N0_cell = np.zeros(np.size(z),dtype=object)
    N1_cell = np.zeros(np.size(z),dtype=object)
    N2_cell = np.zeros(np.size(z),dtype=object)
    for j in np.arange(0,np.size(z)):
        N0 = np.zeros(np.size(z))
        N1 = np.zeros(np.size(z))
        N2 = np.zeros(np.size(z))
        for i in np.arange(0,np.size(z)):
            eps = dz/10.
            zint = np.arange(z[i],2*zb[np.size(zb)-1],eps)
            N0int = n_i( j, zint, z_cell, n_cell )
            N1int = N0int/(H0*fun.Chi_z( zint, H0, Omegam ))
            N2int = N0int/((H0*fun.Chi_z( zint, H0, Omegam ))**2)
            N0[i] = np.trapz(N0int,zint)
            N1[i] = np.trapz(N1int,zint)
            N2[i] = np.trapz(N2int,zint)
        
        N0_cell[j] = N0
        N1_cell[j] = N1
        N2_cell[j] = N2
        
    return N0_cell, N1_cell, N2_cell

#This function computes g_i(z_j), the structure is - - -> [i,j]

def g_z( N0_cell, N1_cell, z, Omegam, H0 ):
    g = np.zeros((np.size(z),np.size(z)))
    for i in np.arange(0,np.size(z)):
        N0 = N0_cell[i]
        N1 = N1_cell[i]
        g[i] = (N0-H0*fun.Chi_z( z, H0, Omegam )*N1)
        
    return g

#This function converts volume galaxy densities into areal galaxy densities
#in units of galaxies per steradian, all in each redshift bin.

def n2D_f( z, zb, nb, H0, Omegam ):
    PreV = np.zeros(np.size(z))
    for i in np.arange(0,np.size(z)):
        PreV[i] = (1./3.)*(((fun.Chi_z( zb[i+1], H0, Omegam ))**3.)-((fun.Chi_z( zb[i], H0, Omegam ))**3.))

    n2D = np.einsum('ai,i->ai',nb,PreV)
    return n2D
