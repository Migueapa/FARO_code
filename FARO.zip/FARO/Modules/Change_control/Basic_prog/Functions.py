# coding=utf-8

#This module contains the basic functions: E(z), f(z), D(z), \chi(z), A_i(z), R(z), L(z), b(z),
#P(k), \sigma (z,k) y \ell_{max} (z)

import numpy as np
from math import *
from scipy.optimize import newton
from classy import Class

cosmo = Class()

#The function E(z)

def E_z( z, Omegam ):
    E = np.sqrt((Omegam*(1.+z)**3.)+1.-Omegam)
    return E

#The function f(z)

def f_z( z, Omegam, gamma ):
    f = (Omegam*((1.+z)**3.)*(1./E_z(z,Omegam))**2.)**gamma
    return f

#The function D(z)

def D_z( z, Omegam, gamma ):
    if np.size(z)==1:
        z=np.array([z])

    D = np.zeros(np.size(z))
    for i in np.arange(0, np.size(z)):
        eps = - 0.005
        N = - np.log(1.+z[i])
        N_int = np.arange(0,N+eps,eps)
        z_int = np.exp(-N_int)-1.
        f = f_z( z_int, Omegam, gamma )
        if np.size(N_int)==1:
            D[i]=1.
        else:
            D[i]=np.exp(np.trapz(f,N_int))


    return D

#The function \chi(z)

def Chi_z( z, H0, Omegam ):
    if np.size(z)==1:
        z=np.array([z])

    C = np.zeros(np.size(z))
    for i in np.arange(0, np.size(z)):
        eps = 0.001
        z_int = np.arange(0,z[i]+eps,eps)
        E_int = E_z( z_int, Omegam )
        C[i] = (1./H0)*np.trapz(1./E_int,z_int)

    return C

#The function A_i (z_a), the structure is - - > [i,a]

def A_z( z, b, Omegam, gamma, s8 ):
    D = D_z( z, Omegam, gamma )
    A = s8*np.einsum('a,ia->ia', D, b)
    return A

#The function R

def R_z( z, Omegam, gamma, s8 ):
    R = s8*D_z( z, Omegam, gamma )*f_z( z, Omegam, gamma )
    return R

#The function L(z)

def L_z( z, Omegam, gamma, s8 ):
    D = D_z( z, Omegam, gamma )
    L = Omegam*D*s8
    return L

#The function b(z)

def b_z( z, Omegam, gamma ):
    D = D_z( z, Omegam, gamma )
    bLRG = 1.7/D
    bELG = 0.84/D
    bELG_euclid = np.sqrt(1.+z)
    bBGS = 1.34/D
    bQS = 0.53+0.289*(1.+z)**2.
    return bLRG, bELG, bQS, bELG_euclid, bBGS

#This function computes the fiducial matter power spectrum
#in a range of k and gives the array "arr".

def P_class( h, Omegam, omegab, ns, s8 ):
    omegacdm = (h**2)*Omegam - omegab
    k = np.logspace(-4,1,500)
    P = np.zeros(np.size(k))
    cosmo.empty()
    param = {'output' : 'mPk', 'P_k_max_h/Mpc' : 15, 'h' : h, 'omega_b' : omegab, 'omega_cdm' : omegacdm, 'n_s' : ns, 'sigma8' : s8}
    cosmo.set(param)
    cosmo.compute()
    for j in np.arange(0,np.size(k)):
        P[j] = cosmo.pk(k[j], 0)
    
    k = k/h
    P = (h**3.)*P
    arr = np.array([k, P]).transpose()
    cosmo.struct_cleanup
    return arr

#The function P(k)

def P_k( k, arr ):
    if np.size(k)==1:
        k=np.array([k])

    k_arr = arr.transpose()[0]
    P_arr = arr.transpose()[1]
    P = np.zeros(np.size(k))
    for i in np.arange(0,np.size(k)):
        kp = k[i]
        if kp>=k_arr[np.size(k_arr)-1]:
            P[i] = (P_arr[np.size(P_arr)-1]*k_arr[np.size(k_arr)-1]**2.33)/kp**2.33
        elif kp<=k_arr[0]:
            P[i] = 0
        else:
            I = np.argmin(abs(k_arr-kp*np.ones((1,np.size(k_arr))))+10**-8)
            if I==np.size(k_arr)-1:
                I = I - 1
                
            m = (P_arr[I+1]-P_arr[I])/(k_arr[I+1]-k_arr[I])
            n = P_arr[I]-m*k_arr[I]
            P[i] = n+m*kp
            
        
    return P

#La función \sigma(z,k)

def sig_z_k( z, k, arr, Omegam, gamma ):
    k_int = np.linspace(10**-5,10,800)
    R = pi/(2.*k)
    sigma_int = (1./(2.*pi**2.))*P_k(k_int,arr)*(k_int**2.)*((3.*(np.sin(k_int*R)-k_int*R*np.cos(k_int*R)))/((k_int*R)**3.))**2.
    sigma = np.sqrt(np.trapz(sigma_int,k_int)*D_z( z, Omegam, gamma )**2.)
    return sigma

#This function computes the values of \ell_{max} (z).

def l_max( z, arr, H0, Omegam, gamma ):
    lmax = np.zeros(np.size(z))
    for i in np.arange(0,np.size(z)):
        def f(x):
            y = sig_z_k( z[i], x, arr, Omegam, gamma )**2.-0.35
            return y
        
        lmax[i] = Chi_z( z[i], H0, Omegam )*newton(f,0.4)
    
    return lmax

#Auxiliar functions for the derivative of P(k).

def f_theta_a( lnk, lnkb, arr ):
    f_t = np.zeros(np.size(lnk))
    for i in np.arange(0,np.size(lnk)):
	k_int = np.linspace(np.exp(lnkb[i]),np.exp(lnkb[i+1]),10)
        R = 8.
        sigma_int = (1./(2.*pi**2.))*P_k(k_int,arr)*(k_int**2.)*((3.*(np.sin(k_int*R)-k_int*R*np.cos(k_int*R)))/((k_int*R)**3.))**2.
        f_t[i] = np.trapz(sigma_int,k_int)

    return f_t


def Theta_f(k, lnk, lnkb, a ):
    dlnk = np.diff(lnkb)
    Theta = np.heaviside(np.log(k)-(lnk[a]-dlnk[a]/2.), 0.5)*np.heaviside((lnk[a]+dlnk[a]/2.)-np.log(k), 0.5)
    return Theta

#Derivatives of the logaritm of \hat{P}(k_c) respect to {\theta_\alpha} parameters DlnP_param[\alpha][c]

def Deriv_lnP( k, lnk, lnkb, arr ):
    k_size = np.size(k)
    n = np.size(lnk)
    f_t = f_theta_a( lnk, lnkb, arr )
    DlnP_param = np.zeros((n-1,k_size))
    for i in np.arange(0,n-1):
	DlnP_param[i] = -(f_t[i+1]/f_t[0])*(Theta_f(k, lnk, lnkb, 0 )) + Theta_f(k, lnk, lnkb, i+1 )

    return DlnP_param

#Derivatives of the logaritm of \hat{P}(k_c) respect to {\theta_\alpha} parameters DlnP_param[\alpha][c]

def Deriv_lnP_lens( l, z, H0, Omegam, lnk, lnkb, arr ):
    Chi = Chi_z( z, H0, Omegam )
    l_size = np.size(l)
    z_size = np.size(z)
    n = np.size(lnk)
    f_t = f_theta_a( lnk, lnkb, arr )
    DlnP_param = np.zeros((n-1,l_size,z_size))
    for i in np.arange(0,n-1):
        for b in np.arange(0,l_size):
            for a in np.arange(0,z_size):
	        DlnP_param[i][b][a] = -(f_t[i+1]/f_t[0])*(Theta_f(l[b]/Chi[a], lnk, lnkb, 0 )) + Theta_f(l[b]/Chi[a], lnk, lnkb, i+1 )



    return DlnP_param
