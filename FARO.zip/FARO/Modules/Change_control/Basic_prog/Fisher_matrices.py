# coding=utf-8

#This module contains the functions that compute the Fisher matrices for clustering, lensing and the cross correlation.
#In addition, an auxiliary function to cut the sum in l for lensing is provided.

import numpy as np
from math import *
import Functions as fun
import Spec_cov as scov
import DP_param as dpa

import Aux_fun as aux

#This function truncates the sum up to the value of l_{max} of the parameter of lower z in each case. 

def lcut_f( z, lmax, dlog ):
    logl = np.arange(np.log(5.),np.log(lmax[np.size(lmax)-1]),dlog)
    nl = np.size(logl)
    lcut = np.zeros((np.size(z),nl))
    for i in np.arange(0,np.size(z)):
	logl = np.arange(np.log(5.),np.log(lmax[i]),dlog)
        nl = np.size(logl)
        lcut[i][0:nl] = np.ones(nl)
    
    return lcut

#This function computes the clustering Fisher matrix for [A, R, E].

def F_clustering( z, zb, dz, nb, b, fsky, arr, S0, H0, Omegam, gamma, s8, lnk, lnkb ):    
    mu = np.linspace(-1,1,200)
    n = np.size(lnk)
    lk = np.linspace(np.log(0.007),np.log(1.),np.around(n*15).astype(int))
    lk_h = np.linspace(np.log(1.),np.log(10.),15)
    dmu = mu[1]-mu[0]
    dlogk = lk[1]-lk[0]
    dlogk_h = lk_h[1]-lk_h[0]
    lk = lk + dlogk/2.
    lk = lk[0:np.size(lk)-1]
    lk_h = lk_h + dlogk_h/2.
    lk_h = lk_h[0:np.size(lk_h)-1]
    k = np.concatenate((np.exp(lk),np.exp(lk_h)))
    dlogk = np.concatenate((dlogk*np.ones(np.size(lk)),dlogk_h*np.ones(np.size(lk_h))))
    P, Kaiser, Cinv = scov.Clustering_P_Kai_C( z, dz, nb, b, k, mu, arr, H0, Omegam, gamma, s8 )
    DPT = dpa.DPT_z_clustering( z, zb, b, mu, k, Kaiser, P, H0, Omegam, gamma, s8, lnk, lnkb, arr )
    f = fun.f_z( z, Omegam, gamma )
    D = fun.D_z( z, Omegam, gamma )
    Sper = 0.785*D*S0
    Spar = 0.785*D*(1.+f)*S0
    A = np.zeros((np.size(z),np.size(mu),np.size(k)))
    for i in np.arange(0,np.size(z)):
	Va = (4*pi*fsky/3.)*(((fun.Chi_z( zb[i+1], H0, Omegam ))**3)-((fun.Chi_z( zb[i], H0, Omegam ))**3))
	for l in np.arange(0,np.size(k)):
	    for m in np.arange(0,np.size(mu)):
		A[i][m][l] = (Va/(8*pi**2.))*dmu*dlogk[l]*(k[l]**3.)*np.exp(-(k[l]*Sper[i])**2.-((k[l]*mu[m])**2.)*(Spar[i]**2.-Sper[i]**2.))
	    


    F = np.einsum('abc,kabcij,acbjl,pabclm,acbmi->kp',A,DPT,Cinv,DPT,Cinv)
    return F

#This function computes the lensing Fisher matrix for [E, L].

def F_lensing( fsky, z, zb, dzL, zm, nt, arr, lnk, lnkb, N0_cell, N1_cell, N2_cell, gint, H0, Omegam, gamma, s8 ):
    dlog = 0.01
    lmax = fun.l_max( z, arr, H0, Omegam, gamma )
    lcut = lcut_f( z, lmax, dlog )
    logl = np.arange(np.log(5.),np.log(lmax[np.size(lmax)-1]),dlog)
    l = np.exp(logl)
    al = fsky*dlog*(2.*l+1.)*l
    nt = nt*1.1817*10**7
    Pkk, Pkka = scov.P_conv( l, z, zb, arr, N0_cell, N1_cell, H0, Omegam, gamma, s8 )
    DPT = dpa.DPT_z_lensing( Pkka, l, lcut, z, zb, lnk, lnkb, arr, N0_cell, N1_cell, N2_cell, H0, Omegam, gamma, s8 )
    Cinv_kk = scov.C_inv_conv( Pkk, l, z, zb, gint, zm, nt )
    F = np.einsum('l,nlij,lkpij,mlkp->nm', al, DPT, Cinv_kk, DPT)
    return F

#This function computes the cross correlation Fisher matrix for [A_i, L, E].

def F_cross( fsky, z, zb, dzL, zm, nt, n2D, b, arr, lnk, lnkb, N0_cell, N1_cell, N2_cell, gint, H0, Omegam, gamma, s8):
    dlog = 0.01
    lmax = fun.l_max( z, arr, H0, Omegam, gamma )
    lcut = lcut_f( z, lmax, dlog )
    logl = np.arange(np.log(5.),np.log(lmax[np.size(lmax)-1]),dlog)
    l = np.exp(logl)
    al = fsky*dlog*(2.*l+1.)*l
    nt = nt*1.1817*10**7
    Pkk, Pkd, Pdd = scov.P_cross( l, z, zb, b, arr, N0_cell, N1_cell, H0, Omegam, gamma, s8 )
    DPT = dpa.DPT_z_clust_lens( Pkd, l, lcut, z, zb, b, lnk, lnkb, arr, N0_cell, N1_cell, N2_cell, H0, Omegam, gamma, s8 )
    Cinv_cross = scov.C_inv_cross( Pdd, Pkk, Pkd, l, z, zb, n2D, gint, zm, nt )
    F = np.einsum('l,nijal,lkbpiaj,mkpbl->nm', al, DPT, Cinv_cross, DPT)
    return F

#This function computes the lensing Fisher matrix for [E, L], and the cross correlation Fisher matrix for [A_i, L, E].

def F_lens_cross( fsky, z, zb, dzL, zm, nt, n2D, b, arr, lnk, lnkb, N0_cell, N1_cell, N2_cell, gint, H0, Omegam, gamma, s8):
    dlog = 0.01
    lmax = fun.l_max( z, arr, H0, Omegam, gamma )
    lcut = lcut_f( z, lmax, dlog )
    logl = np.arange(np.log(5.),np.log(lmax[np.size(lmax)-1]),dlog)
    l = np.exp(logl)
    al = fsky*dlog*(2.*l+1.)*l
    nt = nt*1.1817*10**7
    Pkk, Pkd, Pdd, Pkka = scov.P_conv_cross( l, z, zb, b, arr, N0_cell, N1_cell, H0, Omegam, gamma, s8 )
    Cinv_kk, Cinv_cross = scov.C_inv_conv_cross( Pdd, Pkk, Pkd, l, z, zb, n2D, gint, zm, nt )
    DPT_lens = dpa.DPT_z_lensing( Pkka, l, lcut, z, zb, lnk, lnkb, arr, N0_cell, N1_cell, N2_cell, H0, Omegam, gamma, s8 )  
    DPT_cross = dpa.DPT_z_clust_lens( Pkd, l, lcut, z, zb, b, lnk, lnkb, arr, N0_cell, N1_cell, N2_cell, H0, Omegam, gamma, s8 )
    F_lens = np.einsum('l,nlij,lkpij,mlkp->nm', al, DPT_lens, Cinv_kk, DPT_lens)  
    F_cross = np.einsum('l,nijal,lkbpiaj,mkpbl->nm', al, DPT_cross, Cinv_cross, DPT_cross)
    return F_lens, F_cross
