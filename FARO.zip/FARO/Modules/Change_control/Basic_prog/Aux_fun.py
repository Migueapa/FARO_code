# coding=utf-8
#This module contains the following auxiliary functions: \hat{P}(k), \hat{P}(l/chi), err_{i}^{clust} (z, mu, k), D\chi(z_j)/DE_a and Dg_i(z_j)/DE_a.

import numpy as np
from math import *
import Functions as fun

#This function computes \hat{P}(k) for clustering.

def Pf_z_k( k, s8, arr ):
    P = (1./s8**2.)*fun.P_k( k, arr )
    return P

#This function computes \hat{P}(l_a/(\chi(z_i))) for lensing, the structure is - - > [a,i].

def Pf_z_l( l, z, H0, Omegam, s8, arr ):
    P = np.zeros((np.size(l),np.size(z)))
    for a in np.arange(0,np.size(l)):
	for i in np.arange(0,np.size(z)):
	    P[a][i] = (1./s8**2.)*fun.P_k( l[a]/(fun.Chi_z( z[i], H0, Omegam )), arr )


    return P

#This function computes dlnP(l_a/(\chi(z_i))) for lensing, the structure is - - > [a,i].

def dlnPf_z_l( l, z, H0, Omegam, dlnP_arr ):
    P = np.zeros((np.size(l),np.size(z)))
    for a in np.arange(0,np.size(l)):
	for i in np.arange(0,np.size(z)):
	    P[a][i] = lnP_k( l[a]/(fun.Chi_z( z[i], H0, Omegam )), dlnP_arr )


    return P

#This function computes err_{i}^{clust} (z_a, mu_b, k_c) for clustering, the structure is - - > [i,a,b,c].

def err_z_factor( z, mu, k, b, dz, E, H0 ):
    z_size = np.size(z)
    b_size = np.size(b)/np.size(z)
    mu_size = np.size(mu)
    k_size = np.size(k)
    experr = np.zeros((b_size,z_size,mu_size,k_size))
    for iz in np.arange(0,z_size):
        for ib in np.arange(0,b_size):
    	    for ik in np.arange(0,k_size):
        	for imu in np.arange(0,mu_size):
		    experr[ib][iz][imu][ik] = np.exp(-(1./2.)*((k[ik]*mu[imu]*dz[ib]*(1.+z[iz]))/(H0*E[iz]))**2.)




    return experr

#This function computes D\chi(z_j)/DE_a, the structure is - - > [a,j].

def DchiE_z( z, zb, H0, Omegam ):
    Dchi = np.zeros((np.size(z),np.size(z)))
    for h in np.arange(0,np.size(z)):
        dz = zb[h+1]-zb[h]
        for i in np.arange(0,np.size(z)):
	    if i>=h:
                Dchi[h][i] = -dz/(H0*fun.E_z( z[h],Omegam )**2.)
            else:
                Dchi[h][i] = 0.



    return Dchi

#This function computes Dg_i(z_j)/DE_a, the structure is - - > [a,i,j].

def DgE_z( N1_cell, N2_cell, z, zb, H0, Omegam ):
    Dg = np.zeros((np.size(z),np.size(z),np.size(z)))
    for i in np.arange(0,np.size(z)): 
        N1i = N1_cell[i]
        N2i = N2_cell[i]
        for h in np.arange(0,np.size(z)): 
            dz = zb[h+1]-zb[h]
            for y in np.arange(0,np.size(z)):
                if y>=h:
                    Dg[h][i][y] = ((dz)/(fun.E_z( z[h],Omegam )**2))*(N1i[y]-H0*fun.Chi_z( z[y], H0, Omegam  )*N2i[y])
                else:
                    Dg[h][i][y] = ((dz)/(fun.E_z( z[h],Omegam )**2))*(-H0*fun.Chi_z( z[y], H0, Omegam  )*N2i[h])




    return Dg

#This function computes the array for dlnP/dlnk.

def dlnP_fun( arr ):
    k_arr = arr.transpose()[0]
    P_arr = arr.transpose()[1]
    lnP = np.diff(np.log(P_arr))/np.diff(np.log(k_arr))
    k = k_arr[0:np.size(k_arr)-1]
    dlnP_arr = np.array([k, lnP]).transpose()
    return dlnP_arr

#The function dlnP/dlnk (k).

def lnP_k( k, dlnP_arr ):
    if np.size(k)==1:
        k=np.array([k])

    k_arr = dlnP_arr.transpose()[0]
    P_arr = dlnP_arr.transpose()[1]
    P = np.zeros(np.size(k))
    for i in np.arange(0,np.size(k)):
        kp = k[i]
        if kp>=k_arr[np.size(k_arr)-1]:
            P[i] = 0
        elif kp<=k_arr[0]:
            P[i] = 0
        else:
            I = np.argmin(abs(k_arr-kp*np.ones((1,np.size(k_arr))))+10**-8)
            if I==np.size(k_arr)-1:
                I = I - 1
                
            m = (P_arr[I+1]-P_arr[I])/(k_arr[I+1]-k_arr[I])
            n = P_arr[I]-m*k_arr[I]
            P[i] = n+m*kp
            
        
    return P
