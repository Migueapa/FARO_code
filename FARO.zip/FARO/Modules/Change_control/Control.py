# coding=utf-8

import numpy as np
import Basic_prog.Win_dens as win
import Basic_prog.Functions as fun
import Basic_prog.Fisher_matrices as fis
import Change as chg
import Change_b_f_Sigma as chanfun
from math import *

#This is the combining Fisher matrices function. Given matrix "A" of size Na x Na, and a matrix
#"B" of size Nb x Nb; the function computes the combinated matrix "C" following the order dictated by
#vectors "na" and "nb". Vector na/nb sizes are Na/Nb, na/nb[i] is the possition of A/B_{ii} in the
#final matrix C. If vector na and nb have a common value, that position in the final matrix C
#is the sum of values from A and B.

def Combine( A, B, na, nb ):
    s = 1+np.max(np.array([np.max(na), np.max(nb)]))
    C = np.zeros((int(s),int(s)))
    for i in np.arange(0,np.size(na)):
        for j in np.arange(0,np.size(na)):
            C[int(na[i])][int(na[j])] = C[int(na[i])][int(na[j])]+A[i][j]
        
    
    for i in np.arange(0,np.size(nb)):
        for j in np.arange(0,np.size(nb)):
            C[int(nb[i])][int(nb[j])] = C[int(nb[i])][int(nb[j])]+B[i][j]
        
    
    return C

#This function takes the clustering inputs and computes the Fisher matrix for parameters: [A_i,R,E].

def Clustering_only( z, zb, lnk, lnkb, dzC, nb, b, fsky, S0, Omegam, gamma, s8, arr ):
    H0=3.33566*10**-4
    F_clust = fis.F_clustering( z, zb, dzC, nb, b, fsky, arr, S0, H0, Omegam, gamma, s8, lnk, lnkb )    
    return F_clust

#This function takes the lensing inputs and computes the Fisher matrix for parameters: [E,L].

def Lensing_only( fsky, z, zb, lnk, lnkb, dzL, zm, nt, gint, Omegam, gamma, s8, arr ):
    H0=3.33566*10**-4
    n_cell, z_cell = win.dens_function( z, zb, dzL, zm )
    N0_cell, N1_cell, N2_cell = win.N_funct( z_cell, n_cell, zb, dzL, z, Omegam, H0 )
    F_lens = fis.F_lensing( fsky, z, zb, dzL, zm, nt, arr, lnk, lnkb, N0_cell, N1_cell, N2_cell, gint, H0, Omegam, gamma, s8 )
    return F_lens

#This function takes the clustering and lensing inputs and computes the Fisher matrix for clustering, lensing and
#cross correlation. Then it combines these Fisher matrices into the total Fisher matrix for parameters: [A_i,R,L,E].
#The outups are the total Fisher matrix "F_tot" and the Fisher matrices for clustering "F_clust" and lensing "F_lens" alone.

def Clust_lens_cross( fsky, z, zb, lnk, lnkb, dzL, dzC, zm, nt, nb, b, gint, S0, Omegam, gamma, s8, arr ):
    H0=3.33566*10**-4
    n = np.size(lnk)-1
    n_cell, z_cell = win.dens_function( z, zb, dzL, zm )
    N0_cell, N1_cell, N2_cell = win.N_funct( z_cell, n_cell, zb, dzL, z, Omegam, H0 )
    n2D = win.n2D_f( z, zb, nb, H0, Omegam )
    F_lens, F_cross = fis.F_lens_cross( fsky, z, zb, dzL, zm, nt, n2D, b, arr, lnk, lnkb, N0_cell, N1_cell, N2_cell, gint, H0, Omegam, gamma, s8)
    F_clust = fis.F_clustering( z, zb, dzC, nb, b, fsky, arr, S0, H0, Omegam, gamma, s8, lnk, lnkb )
    b_size = np.size(b)/np.size(z)
    n_clust = np.arange(0,n,1)
    n_lens = np.arange(0,n,1)
    for i in np.arange(0,np.size(z)):
        for j in np.arange(0,b_size):
	    n_clust = np.concatenate((n_clust,n+np.array([(b_size+3)*i+j])))
	    
        n_clust = np.concatenate((n_clust,n+np.array([(b_size+3)*i+b_size,(b_size+3)*i+b_size+2])))
        n_lens = np.concatenate((n_lens,n+np.array([(b_size+3)*i+b_size+2,(b_size+3)*i+b_size+1])))

    F_clust_lens = Combine( F_clust, F_lens, n_clust, n_lens )
    b_size = np.size(b)/np.size(z)
    n_clust_lens = np.arange(0,n,1)
    n_cross = np.arange(0,n,1)
    for i in np.arange(0,np.size(z)):
        for j in np.arange(0,b_size):
	    n_clust_lens = np.concatenate((n_clust_lens,n+np.array([(b_size+3)*i+j])))
	    n_cross = np.concatenate((n_cross,n+np.array([(b_size+3)*i+j])))
	    
        n_clust_lens = np.concatenate((n_clust_lens,n+np.array([(b_size+3)*i+b_size,(b_size+3)*i+b_size+1,(b_size+3)*i+b_size+2])))
        n_cross = np.concatenate((n_cross,n+np.array([(b_size+3)*i+b_size+1,(b_size+3)*i+b_size+2])))

    F_tot = Combine( F_clust_lens, F_cross, n_clust_lens, n_cross )
    return F_tot, F_clust, F_lens

#This function takes the initial Fisher matrix for clustering and makes the change of
#variable to the Fisher matrix "F_clust_new" of: [b_i,f,E]. It takes into account the Planck prior
#for \sigma_8 value.

def Clustering_change( F_clust, z, zb, b, Omegam, gamma, s8 ):
    b_size = np.size(b)/np.size(z)
    Finv = np.linalg.inv(F_clust)
    n = Finv.shape[0] - (2+b_size)*np.size(z)
    F_clust = np.linalg.inv(Finv[n:Finv.shape[0]][:,n:Finv.shape[0]])
    ds8 = 0.0073
    size_F = np.size(F_clust,0)
    F_clust_s8 = np.zeros((size_F+1,size_F+1))
    F_clust_s8[1:(size_F+1)][:,1:(size_F+1)] = F_clust
    F_clust_s8[0][0] = 1./(ds8**2.)
    DADA, DADR, DADE, DRDA, DRDR, DRDE, DEDA, DEDR, DEDE = chanfun.Deriv_clustering( z, zb, b, Omegam, gamma, s8 )   
    P_change = chg.Change_clustering_loc( DADA, DADR, DADE, DRDA, DRDR, DRDE, DEDA, DEDR, DEDE )
    DADs8 = fun.A_z( z, b, Omegam, gamma, s8 )/s8
    DRDs8 = fun.R_z( z, Omegam, gamma, s8 )/s8
    DEDs8 = np.zeros(np.size(z))
    size_P = np.size(P_change,0)
    P_change_s8 = np.zeros((size_P+1,size_P+1))
    P_change_s8[1:(size_P+1)][:,1:(size_P+1)] = P_change
    P_change_s8[0][0] = 1.
    for i in np.arange(0,np.size(z)):
        for j in np.arange(0,b_size):
	    P_change_s8[1+(b_size+2)*i+j][0] = DADs8[j][i]

        P_change_s8[1+(b_size+2)*i+b_size][0] = DRDs8[i]
        P_change_s8[1+(b_size+2)*i+b_size+1][0] = DEDs8[i]

    F_clust_new_s8 = chg.New_Fisher( P_change_s8, F_clust_s8 )
    Finv = np.linalg.inv(F_clust_new_s8)
    Finv_marg = Finv[1:(size_F+1)][:,1:(size_F+1)]
    F_clust_new = np.linalg.inv(Finv_marg)
    return F_clust_new

#This function takes the initial Fisher matrix for the combination of clustering and lensing and makes the change of
#variable to the Fisher matrix "F_tot_new" of: [b_i,f,\Sigma,E]. It takes into account the Planck prior for \sigma_8 value.

def Clust_lens_cross_change( F_tot, z, zb, b, Omegam, gamma, s8 ):
    b_size = np.size(b)/np.size(z)
    Finv = np.linalg.inv(F_tot)
    n = Finv.shape[0] - (3+b_size)*np.size(z)
    F_tot = np.linalg.inv(Finv[n:Finv.shape[0]][:,n:Finv.shape[0]])
    ds8 = 0.0073
    size_F = np.size(F_tot,0)
    F_tot_s8 = np.zeros((size_F+1,size_F+1))
    F_tot_s8[1:(size_F+1)][:,1:(size_F+1)] = F_tot
    F_tot_s8[0][0] = 1./(ds8**2.)
    DADA, DADR, DADL, DADE, DRDA, DRDR, DRDL, DRDE, DLDA, DLDR, DLDL, DLDE, DEDA, DEDR, DEDL, DEDE = chanfun.Deriv_clust_lens( z, zb, b, Omegam, gamma, s8 )
    P_change = chg.Change_clust_lens_loc( DADA, DADR, DADL, DADE, DRDA, DRDR, DRDL, DRDE, DLDA, DLDR, DLDL, DLDE, DEDA, DEDR, DEDL, DEDE )
    DADs8 = fun.A_z( z, b, Omegam, gamma, s8 )/s8
    DRDs8 = fun.R_z( z, Omegam, gamma, s8 )/s8
    DLDs8 = fun.L_z( z, Omegam, gamma, s8 )/s8
    DEDs8 = np.zeros(np.size(z))
    size_P = np.size(P_change,0)
    P_change_s8 = np.zeros((size_P+1,size_P+1))
    P_change_s8[1:(size_P+1)][:,1:(size_P+1)] = P_change
    P_change_s8[0][0] = 1.
    for i in np.arange(0,np.size(z)):
        for j in np.arange(0,b_size):
	    P_change_s8[1+(b_size+3)*i+j][0] = DADs8[j][i]

        P_change_s8[1+(b_size+3)*i+b_size][0] = DRDs8[i]
        P_change_s8[1+(b_size+3)*i+b_size+1][0] = DLDs8[i]
        P_change_s8[1+(b_size+3)*i+b_size+2][0] = DEDs8[i]

    F_tot_new_s8 = chg.New_Fisher( P_change_s8, F_tot_s8 )
    Finv = np.linalg.inv(F_tot_new_s8)
    Finv_marg = Finv[1:(size_F+1)][:,1:(size_F+1)]
    F_tot_new = np.linalg.inv(Finv_marg)
    return F_tot_new
