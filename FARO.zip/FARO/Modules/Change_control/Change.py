# coding=utf-8

import numpy as np

#This function computes the change of variable matrix for clustering.
#Change of variable for clustering: [A_i^{a},R_i,E_i] - - > [NA_i^{a},NR_i,NE_i]
#As input we need the derivatives of old parameters respect to new ones, the structure is:
#"DADA" -> DA_i^{a}/DNA_j^{b} - - > [i,j,a,b]
#"DADR" -> DA_i^{a}/DNR_j - - > [i,j,a]
#"DADE" -> DA_i^{a}/DNE_j - - > [i,j,a]
#"DRDA" -> DR_i/DNA_j^{b} - - > [i,j,b]
#"DRDR" -> DR_i/DNR_j - - > [i,j]
#"DRDE" -> DR_i/DNE_j - - > [i,j]
#"DEDA" -> DE_i/DNA_j^{b} - - > [i,j,b]
#"DEDR" -> DE_i/DNR_j - - > [i,j]
#"DEDE" -> DE_i/DNE_j - - > [i,j]

def Change_clustering_loc( DADA, DADR, DADE, DRDA, DRDR, DRDE, DEDA, DEDR, DEDE ):
    z_size = np.sqrt(np.size(DRDR)).astype(int)
    b_size = (np.sqrt(np.size(DADA))/z_size).astype(int)
    P_change = np.zeros(((b_size+2)*z_size,(b_size+2)*z_size))
    for i in np.arange(0,z_size):
        for j in np.arange(0,z_size):
	    for a in np.arange(0,b_size):
		for b in np.arange(0,b_size):
		    P_change[(b_size+2)*i+a][(b_size+2)*j+b] = DADA[i][j][a][b]
		    P_change[(b_size+2)*i+a][(b_size+2)*j+b_size] = DADR[i][j][a]
		    P_change[(b_size+2)*i+a][(b_size+2)*j+b_size+1] = DADE[i][j][a]
		    P_change[(b_size+2)*i+b_size][(b_size+2)*j+b] = DRDA[i][j][b]
		    P_change[(b_size+2)*i+b_size+1][(b_size+2)*j+b] = DEDA[i][j][b]


	    P_change[(b_size+2)*i+b_size][(b_size+2)*j+b_size] = DRDR[i][j]
	    P_change[(b_size+2)*i+b_size][(b_size+2)*j+b_size+1] = DRDE[i][j]
	    P_change[(b_size+2)*i+b_size+1][(b_size+2)*j+b_size] = DEDR[i][j]
	    P_change[(b_size+2)*i+b_size+1][(b_size+2)*j+b_size+1] = DEDE[i][j]


    return P_change

#This function computes the change of variable matrix for lensing.
#Change of variable for lensing: [E_i,L_i] - - > [NE_i,NL_i]
#As input we need the derivatives of old parameters respect to new ones, the structure is:
#"DEDE" -> DE_i/DNE_j - - > [i,j]
#"DEDL" -> DE_i/DNL_j - - > [i,j]
#"DLDE" -> DL_i/DNE_j - - > [i,j]
#"DLDL" -> DL_i/DNL_j - - > [i,j]

def Change_lensing_loc( DEDE, DEDL, DLDE, DLDL ):
    z_size = np.sqrt(np.size(DEDE)).astype(int)
    P_change = np.zeros((2*z_size,2*z_size))
    for i in np.arange(0,z_size):
        for j in np.arange(0,z_size):
	    P_change[2*i][2*j] = DEDE[i][j]
	    P_change[2*i][2*j+1] = DEDL[i][j]
	    P_change[2*i+1][2*j] = DLDE[i][j]
	    P_change[2*i+1][2*j+1] = DLDL[i][j]


    return P_change

#This function computes the change of variable matrix for the combination of clustering and lensing.
#Change of variable for the combination of clustering and lensing: [A_i^{a},R_i,L_i,E_i] - - > [NA_i^{a},NR_i,NL_i,NE_i]
#As input we need the derivatives of old parameters respect to new ones, the structure is:
#"DADA" -> DA_i^{a}/DNA_j^{b} - - > [i,j,a,b]
#"DADR" -> DA_i^{a}/DNR_j - - > [i,j,a]
#"DADL" -> DA_i^{a}/DNL_j - - > [i,j,a]
#"DADE" -> DA_i^{a}/DNE_j - - > [i,j,a]
#"DRDA" -> DR_i/DNA_j^{b} - - > [i,j,b]
#"DRDR" -> DR_i/DNR_j - - > [i,j]
#"DRDL" -> DR_i/DNL_j - - > [i,j]
#"DRDE" -> DR_i/DNE_j - - > [i,j]
#"DLDA" -> DL_i/DNA_j^{b} - - > [i,j,b]
#"DLDR" -> DL_i/DNR_j - - > [i,j]
#"DLDL" -> DL_i/DNL_j - - > [i,j]
#"DLDE" -> DL_i/DNE_j - - > [i,j]
#"DEDA" -> DE_i/DNA_j^{b} - - > [i,j,b]
#"DEDR" -> DE_i/DNR_j - - > [i,j]
#"DEDL" -> DE_i/DNL_j - - > [i,j]
#"DEDE" -> DE_i/DNE_j - - > [i,j]

def Change_clust_lens_loc( DADA, DADR, DADL, DADE, DRDA, DRDR, DRDL, DRDE, DLDA, DLDR, DLDL, DLDE, DEDA, DEDR, DEDL, DEDE ):
    z_size = np.sqrt(np.size(DRDR)).astype(int)
    b_size = (np.sqrt(np.size(DADA))/z_size).astype(int)
    P_change = np.zeros(((b_size+3)*z_size,(b_size+3)*z_size))
    for i in np.arange(0,z_size):
        for j in np.arange(0,z_size):
	    for a in np.arange(0,b_size):
		for b in np.arange(0,b_size):
		    P_change[(b_size+3)*i+a][(b_size+3)*j+b] = DADA[i][j][a][b]
		    P_change[(b_size+3)*i+a][(b_size+3)*j+b_size] = DADR[i][j][a]
		    P_change[(b_size+3)*i+a][(b_size+3)*j+b_size+1] = DADL[i][j][a]
		    P_change[(b_size+3)*i+a][(b_size+3)*j+b_size+2] = DADE[i][j][a]
		    P_change[(b_size+3)*i+b_size][(b_size+3)*j+b] = DRDA[i][j][b]
		    P_change[(b_size+3)*i+b_size+1][(b_size+3)*j+b] = DLDA[i][j][b]
		    P_change[(b_size+3)*i+b_size+2][(b_size+3)*j+b] = DEDA[i][j][b]


	    P_change[(b_size+3)*i+b_size][(b_size+3)*j+b_size] = DRDR[i][j]
	    P_change[(b_size+3)*i+b_size][(b_size+3)*j+b_size+1] = DRDL[i][j]
	    P_change[(b_size+3)*i+b_size][(b_size+3)*j+b_size+2] = DRDE[i][j]
	    P_change[(b_size+3)*i+b_size+1][(b_size+3)*j+b_size] = DLDR[i][j]
	    P_change[(b_size+3)*i+b_size+1][(b_size+3)*j+b_size+1] = DLDL[i][j]
	    P_change[(b_size+3)*i+b_size+1][(b_size+3)*j+b_size+2] = DLDE[i][j]
	    P_change[(b_size+3)*i+b_size+2][(b_size+3)*j+b_size] = DEDR[i][j]
	    P_change[(b_size+3)*i+b_size+2][(b_size+3)*j+b_size+1] = DEDL[i][j]
	    P_change[(b_size+3)*i+b_size+2][(b_size+3)*j+b_size+2] = DEDE[i][j]


    return P_change

#Given the redshift bins "z" and the number of tracers "num_b", this function gives the trivial change 
#of variable. Can be used as a template for a change of variable with the same number of parameters
#of the clustering Fisher matrix.

def Deriv_ident_clustering( z, num_b ):
    z_size = np.size(z)
    b_size = num_b
    Ident_z = np.eye(z_size)
    zeros_z = np.zeros((z_size,z_size))
    Ident_b = np.eye(b_size)
    Vi_b = np.ones(b_size)
    DADA = np.einsum('ij,ab->ijab',Ident_z,Ident_b)
    DADR = np.einsum('ij,a->ija',zeros_z,Vi_b)
    DADE = np.einsum('ij,a->ija',zeros_z,Vi_b)
    DRDA = np.einsum('ij,b->ijb',zeros_z,Vi_b)
    DRDR = np.einsum('ij->ij',Ident_z)
    DRDE = np.einsum('ij->ij',zeros_z)
    DEDA = np.einsum('ij,b->ijb',zeros_z,Vi_b)
    DEDR = np.einsum('ij->ij',zeros_z)
    DEDE = np.einsum('ij->ij',Ident_z)
    return DADA, DADR, DADE, DRDA, DRDR, DRDE, DEDA, DEDR, DEDE

#Given the redshift bins "z", this function gives the trivial change of variable. Can be used 
#as a template for a change of variable with the same number of parameters of the lensing Fisher matrix.

def Deriv_ident_lensing( z ):
    z_size = np.size(z)
    Ident_z = np.eye(z_size)
    zeros_z = np.zeros((z_size,z_size))
    DEDE = np.einsum('ij->ij',Ident_z)
    DEDL = np.einsum('ij->ij',zeros_z)
    DLDE = np.einsum('ij->ij',zeros_z)
    DLDL = np.einsum('ij->ij',Ident_z)
    return DEDE, DEDL, DLDE, DLDL

#Given the redshift bins "z" and the number of tracers "num_b", this function gives the trivial change 
#of variable. Can be used as a template for a change of variable with the same number of parameters
#of the combination of clustering and lensing Fisher matrix.

def Deriv_ident_clust_lens( z, num_b ):
    z_size = np.size(z)
    b_size = num_b
    Ident_z = np.eye(z_size)
    zeros_z = np.zeros((z_size,z_size))
    Ident_b = np.eye(b_size)
    Vi_b = np.ones(b_size)
    DADA = np.einsum('ij,ab->ijab',Ident_z,Ident_b)
    DADR = np.einsum('ij,a->ija',zeros_z,Vi_b)
    DADL = np.einsum('ij,a->ija',zeros_z,Vi_b)
    DADE = np.einsum('ij,a->ija',zeros_z,Vi_b)
    DRDA = np.einsum('ij,b->ijb',zeros_z,Vi_b)
    DRDR = np.einsum('ij->ij',Ident_z)
    DRDL = np.einsum('ij->ij',zeros_z)
    DRDE = np.einsum('ij->ij',zeros_z)
    DLDA = np.einsum('ij,b->ijb',zeros_z,Vi_b)
    DLDR = np.einsum('ij->ij',zeros_z)
    DLDL = np.einsum('ij->ij',Ident_z)
    DLDE = np.einsum('ij->ij',zeros_z)
    DEDA = np.einsum('ij,b->ijb',zeros_z,Vi_b)
    DEDR = np.einsum('ij->ij',zeros_z)
    DEDL = np.einsum('ij->ij',zeros_z)
    DEDE = np.einsum('ij->ij',Ident_z)
    return DADA, DADR, DADL, DADE, DRDA, DRDR, DRDL, DRDE, DLDA, DLDR, DLDL, DLDE, DEDA, DEDR, DEDL, DEDE

#This function computes the change of variable from an initial Fisher matrix "F" to a final Fisher matrix "F_new"
#given the change of variable matrix "P_change".

def New_Fisher( P_change, F ):
    F_new = np.dot(np.dot(P_change.transpose(),F),P_change)
    return F_new
