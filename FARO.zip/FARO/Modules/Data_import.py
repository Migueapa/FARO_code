# coding=utf-8

import numpy as np

#This function loads the inputs for a clustering survey with name saved as: "name".

def Data_survey_clust( name ):
    direc = './Results/Clustering_only/' + name + '/Model_independent/Data_survey/'
    exten_data = '_data.npz'
    loaded = np.load( direc + name + exten_data )
    Omegam = loaded['Fiducial'][0]
    gamma = loaded['Fiducial'][1]
    h = loaded['Fiducial'][2]
    omegab = loaded['Fiducial'][3]
    ns = loaded['Fiducial'][4]
    s8 = loaded['Fiducial'][5]
    arr = loaded['arr']
    z = loaded['z']
    zb = loaded['zb']
    lnk = loaded['lnk']
    lnkb = loaded['lnkb']
    nb = loaded['nb']
    S0 = loaded['S0']
    b = loaded['b']
    fsky = loaded['fsky']
    dzC = loaded['dzC']
    return z, zb, lnk, lnkb, dzC, nb, b, fsky, S0, Omegam, gamma, h, omegab, ns, s8, arr

#This function loads the inputs for a lensing survey with name saved as: "name".

def Data_survey_lens( name ):
    direc = './Results/Weak_lensing_only/' + name + '/Data_survey/'
    exten_data = '_data.npz'
    loaded = np.load( direc + name + exten_data )
    Omegam = loaded['Fiducial'][0]
    gamma = loaded['Fiducial'][1]
    h = loaded['Fiducial'][2]
    omegab = loaded['Fiducial'][3]
    ns = loaded['Fiducial'][4]
    s8 = loaded['Fiducial'][5]
    arr = loaded['arr']
    z = loaded['z']
    zb = loaded['zb']
    lnk = loaded['lnk']
    lnkb = loaded['lnkb']
    dzL = loaded['dzL']
    gint = loaded['gint']
    nt = loaded['nt']
    zm = loaded['zm']
    fsky = loaded['fsky']
    return z, zb, lnk, lnkb, dzL, gint, nt, zm, fsky, Omegam, gamma, h, omegab, ns, s8, arr

#This function loads the inputs for a clustering and lensing survey with name saved as: "name".

def Data_survey_clust_lens( name ):
    direc = './Results/Clustering_lensing_cross/' + name + '/Model_independent/Data_survey/'
    exten_data = '_data.npz'
    loaded = np.load( direc + name + exten_data )
    Omegam = loaded['Fiducial'][0]
    gamma = loaded['Fiducial'][1]
    h = loaded['Fiducial'][2]
    omegab = loaded['Fiducial'][3]
    ns = loaded['Fiducial'][4]
    s8 = loaded['Fiducial'][5]
    arr = loaded['arr']
    z = loaded['z']
    zb = loaded['zb']
    lnk = loaded['lnk']
    lnkb = loaded['lnkb']
    nb = loaded['nb']
    S0 = loaded['S0']
    gint = loaded['gint']
    b = loaded['b']
    fsky = loaded['fsky']
    dzC = loaded['dzC']
    dzL = loaded['dzL']
    nt = loaded['nt']
    zm = loaded['zm']
    return z, zb, lnk, lnkb, dzC, dzL, nb, b, nt, zm, fsky, S0, gint, Omegam, gamma, h, omegab, ns, s8, arr
