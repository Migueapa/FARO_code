# coding=utf-8

import numpy as np
import Change_control.Basic_prog.Functions as fun
import Data_import as imp
import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt

#We define an auxiliar function to obtain errors for P(k) and the Fisher submatrix for z parameters.

def P_k_errors(F, lnk, lnkb, arr ):
    k = np.exp(lnk)
    DlnP_param = fun.Deriv_lnP( k, lnk, lnkb, arr )
    P0 = fun.P_k( k, arr )
    a = np.einsum('pc,c->pc',DlnP_param,P0)
    n = np.size(lnk)-1
    Finv = np.linalg.inv(F)
    M_k = Finv[0:n][:,0:n]
    M_z = Finv[n:Finv.shape[0]][:,n:Finv.shape[0]]
    F_z = np.linalg.inv(M_z)
    DP0 = np.sqrt(np.einsum('ic,ij,jc->c',a,M_k,a))
    return F_z, k, P0, DP0

################################################################
#CLUSTERING
################################################################
#Giving the name of the survey "name" and the bias names "bias_names", this function loads the Fisher matrices for clustering and the inputs of the survey, then
#it computes the errors and generates the tables.

def table_generator_clust( name, bias_names ):
    direc_mi = './Results/Clustering_only/' + name + '/Model_independent/Fisher_matrices/'
    direc_chv = './Results/Clustering_only/' + name + '/Change_variable/Fisher_matrices/'
    exten_p_A_R_E = '_Fisher_p_A_R_E.out'
    direc_p_A_R_E = direc_mi + name + exten_p_A_R_E
    exten_b_f_E = '_Fisher_b_f_E.out'
    direc_b_f_E = direc_chv + name + exten_b_f_E
    F_p_A_R_E = np.loadtxt(direc_p_A_R_E)
    F_b_f_E = np.loadtxt(direc_b_f_E)
    z, zb, lnk, lnkb, dzC, nb, b, fsky, S0, Omegam, gamma, h, omegab, ns, s8, arr = imp.Data_survey_clust( name )
    F_A_R_E, k, P0, DP0 = P_k_errors(F_p_A_R_E, lnk, lnkb, arr )
    A = fun.A_z( z, b, Omegam, gamma, s8 )
    R = fun.R_z( z, Omegam, gamma, s8 )
    E = fun.E_z( z, Omegam )
    f = fun.f_z( z, Omegam, gamma )
    dA = np.zeros(np.size(A))
    dA.shape = A.shape
    db = np.zeros(np.size(b))
    db.shape = b.shape
    dR = np.zeros(np.size(R))
    dE = np.zeros(np.size(E))
    df = np.zeros(np.size(f))
    F_A_R_E_inv = np.linalg.inv(F_A_R_E)
    F_b_f_E_inv = np.linalg.inv(F_b_f_E)
    b_size = np.size(b)/np.size(z)
    for i in np.arange(0,np.size(z)):
	for j in np.arange(0,b_size):
	    dA[j][i] = np.sqrt(F_A_R_E_inv[(b_size+2)*i+j][(b_size+2)*i+j])
	    db[j][i] = np.sqrt(F_b_f_E_inv[(b_size+2)*i+j][(b_size+2)*i+j])

	dR[i] = np.sqrt(F_A_R_E_inv[(b_size+2)*i+b_size][(b_size+2)*i+b_size])
	df[i] = np.sqrt(F_b_f_E_inv[(b_size+2)*i+b_size][(b_size+2)*i+b_size])
	dE[i] = np.sqrt(F_A_R_E_inv[(b_size+2)*i+b_size+1][(b_size+2)*i+b_size+1])


    dAp = 100*(dA/A)
    dbp = 100*(db/b)
    dRp = 100*(dR/R)
    dfp = 100*(df/f)
    dEp = 100*(dE/E)

    dPp = 100*(DP0/P0)

    hed_A_R_E = ' z'
    hed_b_f_E = ' z'
    for j in np.arange(0,b_size):
        hed_A_R_E = hed_A_R_E + '     A_' + bias_names[j]

    for j in np.arange(0,b_size):
        hed_A_R_E = hed_A_R_E + '     dA_' + bias_names[j]
    
    for j in np.arange(0,b_size):
        hed_A_R_E = hed_A_R_E + '     dA_' + bias_names[j] + '/A_' + bias_names[j] + ' (%)'

    for j in np.arange(0,b_size):
        hed_b_f_E = hed_b_f_E + '     b_' + bias_names[j]

    for j in np.arange(0,b_size):
        hed_b_f_E = hed_b_f_E + '     db_' + bias_names[j]
    
    for j in np.arange(0,b_size):
        hed_b_f_E = hed_b_f_E + '     db_' + bias_names[j] + '/b_' + bias_names[j] + ' (%)'

    hed_A_R_E = hed_A_R_E + '    R    dR    dR/R (%)    E    dE    dE/E (%)    '
    DATA = ((np.concatenate((z,A.reshape(np.size(A)),dA.reshape(np.size(dA)),dAp.reshape(np.size(dAp)),R, dR, dRp, E, dE, dEp))).reshape(1+(2+b_size)*3,np.size(z))).transpose()
    direc = './Results/Clustering_only/' + name + '/Model_independent/Tables/'
    exten_A_R_E = '_errors_A_R_E.out'
    direc_table = direc + name + exten_A_R_E
    np.savetxt(direc_table, DATA, fmt='%1.2e', delimiter='  |  ',header=hed_A_R_E)

    hed_b_f_E = hed_b_f_E + '    f    df    df/f (%)    E    dE    dE/E (%)    '
    DATA = ((np.concatenate((z,b.reshape(np.size(b)),db.reshape(np.size(db)),dbp.reshape(np.size(dbp)), f, df, dfp, E, dE, dEp))).reshape(1+(2+b_size)*3,np.size(z))).transpose()
    direc = './Results/Clustering_only/' + name + '/Change_variable/Tables/'
    exten_b_f_E = '_errors_b_f_E.out'
    direc_table = direc + name + exten_b_f_E
    np.savetxt(direc_table, DATA, fmt='%1.2e', delimiter='  |  ',header=hed_b_f_E)

    DATA = ((np.concatenate((k,P0,DP0,dPp))).reshape(4,np.size(k))).transpose()
    direc = './Results/Clustering_only/' + name + '/Model_independent/Tables/'
    exten = '_errors_P_k.out'
    direc_table = direc + name + exten
    np.savetxt(direc_table, DATA, fmt='%1.2e', delimiter='  |  ',header=' k    P    dP    dP/P (%)')

    return z, k, P0, DP0, dPp, A, dA, dAp, b, db, dbp, R, dR, dRp, f, df, dfp, E, dE, dEp

#Giving the name of the survey "name" and the bias names "bias_names", computes the errors and tables for clustering and makes the plots.

def plot_generator_clust( name, bias_names ):
    direc_mi = './Results/Clustering_only/' + name + '/Model_independent/Plots/'
    direc_chv = './Results/Clustering_only/' + name + '/Change_variable/Plots/'
    z, k, P0, DP0, dPp, A, dA, dAp, b, db, dbp, R, dR, dRp, f, df, dfp, E, dE, dEp = table_generator_clust( name, bias_names )
    b_size = np.size(b)/np.size(z)
    for j in np.arange(0,b_size):
        fig = plt.figure()
        b_plot = plt.semilogy(z,dbp[j], color="black", linewidth=1.5, linestyle="-")
        if np.amax(dbp[j]) > 100.:
            plt.ylim(np.amin(dbp[j])/2.,100)

        plt.xlabel("z", fontsize = 20)
        labely = "$\Delta \, b_{" + bias_names[j] + "} \, / \, b_{" + bias_names[j] + "}$ (%)"
        plt.ylabel(labely, fontsize = 20)
        ext_b = '_err_b_' + bias_names[j] + '.pdf'
        plt.savefig(direc_chv + name + ext_b, format='pdf',bbox_inches="tight", pad_inches = 0.3)
        fig = plt.figure()
        A_plot = plt.semilogy(z,dAp[j], color="black", linewidth=1.5, linestyle="-")
        if np.amax(dAp[j]) > 100.:
            plt.ylim(np.amin(dAp[j])/2.,100)

        plt.xlabel("z", fontsize = 20)
        labely = "$\Delta \, A_{" + bias_names[j] + "} \, / \, A_{" + bias_names[j] + "}$ (%)"
        plt.ylabel(labely, fontsize = 20)
        ext_A = '_err_A_' + bias_names[j] + '.pdf'
        plt.savefig(direc_mi + name + ext_A, format='pdf',bbox_inches="tight", pad_inches = 0.3)

    fig = plt.figure()
    R_plot = plt.semilogy(z,dRp, color="black", linewidth=1.5, linestyle="-")
    plt.xlabel("z", fontsize = 20)
    plt.ylabel("$\Delta \, R \, / \, R$ (%)", fontsize = 20)
    ext_R = '_err_R.pdf'
    plt.savefig(direc_mi + name + ext_R, format='pdf',bbox_inches="tight", pad_inches = 0.3)
    fig = plt.figure()
    f_plot = plt.semilogy(z,dfp, color="black", linewidth=1.5, linestyle="-")
    plt.xlabel("z", fontsize = 20)
    plt.ylabel("$\Delta \, f \, / \, f$ (%)", fontsize = 20)
    ext_f = '_err_f.pdf'
    plt.savefig(direc_chv + name + ext_f, format='pdf',bbox_inches="tight", pad_inches = 0.3)
    fig = plt.figure()
    E_plot = plt.semilogy(z,dEp, color="black", linewidth=1.5, linestyle="-")
    plt.xlabel("z", fontsize = 20)
    plt.ylabel("$\Delta \, E \, / \, E$ (%)", fontsize = 20)
    ext_E = '_err_E.pdf'
    plt.savefig(direc_mi + name + ext_E, format='pdf',bbox_inches="tight", pad_inches = 0.3)
    fig = plt.figure()
    P_plot = plt.loglog(k,dPp, color="black", linewidth=1.5, linestyle="-")
    plt.xlabel("k $(h/Mpc)$", fontsize = 20)
    plt.ylabel("$\Delta \, \hat{P} \, / \, \hat{P}$ (%)", fontsize = 20)
    ext_eP = '_err_P.pdf'
    plt.savefig(direc_mi + name + ext_eP, format='pdf',bbox_inches="tight", pad_inches = 0.3)


################################################################
#WEAK LENSING
################################################################
#Giving the name of the survey "name", this function loads the Fisher matrices for lensing and the inputs of the survey, then
#it computes the errors and generates the tables.

def table_generator_lens( name ):
    direc = './Results/Weak_lensing_only/' + name + '/Fisher_matrices/'
    exten_p_E_L = '_Fisher_p_E_L.out'
    direc_p_E_L = direc + name + exten_p_E_L
    F_p_E_L = np.loadtxt(direc_p_E_L)
    z, zb, lnk, lnkb, dzL, gint, nt, zm, fsky, Omegam, gamma, h, omegab, ns, s8, arr = imp.Data_survey_lens( name )
    F_E_L, k, P0, DP0 = P_k_errors(F_p_E_L, lnk, lnkb, arr )
    L = fun.L_z( z, Omegam, gamma, s8 )
    E = fun.E_z( z, Omegam )
    dL = np.zeros(np.size(L))
    dE = np.zeros(np.size(E))
    F_E_L_inv = np.linalg.inv(F_E_L)
    for i in np.arange(0,np.size(z)):
	dL[i] = np.sqrt(F_E_L_inv[(2)*i+1][(2)*i+1])
	dE[i] = np.sqrt(F_E_L_inv[(2)*i][(2)*i])

    dLp = 100*(dL/L)
    dEp = 100*(dE/E)
    dPp = 100*(DP0/P0)
    DATA = ((np.concatenate((z, L, dL, dLp, E, dE, dEp))).reshape(7,np.size(z))).transpose()
    direc = './Results/Weak_lensing_only/' + name + '/Tables/'
    exten = '_errors.out'
    direc_table = direc + name + exten
    np.savetxt(direc_table, DATA, fmt='%1.2e', delimiter='  |  ',header=' z   L   dL   dL/L (%)   E   dE   dE/E (%)')

    DATA = ((np.concatenate((k,P0,DP0,dPp))).reshape(4,np.size(k))).transpose()
    direc = './Results/Weak_lensing_only/' + name + '/Tables/'
    exten = '_errors_P_k.out'
    direc_table = direc + name + exten
    np.savetxt(direc_table, DATA, fmt='%1.2e', delimiter='  |  ',header=' k    P    dP    dP/P (%)')

    return z, k, P0, DP0, dPp, L, dL, dLp, E, dE, dEp, dPp

#Giving the name of the survey "name", computes the errors and tables for lensing and makes the plots.

def plot_generator_lens( name ):
    direc = './Results/Weak_lensing_only/' + name + '/Plots/'
    z, k, P0, DP0, dPp, L, dL, dLp, E, dE, dEp, dPp = table_generator_lens( name )
    fig = plt.figure()
    L_plot = plt.semilogy(z,dLp, color="black", linewidth=1.5, linestyle="-")
    plt.xlabel("z", fontsize = 20)
    plt.ylabel("$\Delta \, L \, / \, L$ (%)", fontsize = 20)
    ext_L = '_err_L.pdf'
    plt.savefig(direc + name + ext_L, format='pdf',bbox_inches="tight", pad_inches = 0.3)
    fig = plt.figure()
    E_plot = plt.semilogy(z,dEp, color="black", linewidth=1.5, linestyle="-")
    plt.xlabel("z", fontsize = 20)
    plt.ylabel("$\Delta \, E \, / \, E$ (%)", fontsize = 20)
    ext_E = '_err_E.pdf'
    plt.savefig(direc + name + ext_E, format='pdf',bbox_inches="tight", pad_inches = 0.3)
    fig = plt.figure()
    P_plot = plt.loglog(k,dPp, color="black", linewidth=1.5, linestyle="-")
    plt.xlabel("k $(h/Mpc)$", fontsize = 20)
    plt.ylabel("$\Delta \, \hat{P} \, / \, \hat{P}$ (%)", fontsize = 20)
    ext_eP = '_err_P.pdf'
    plt.savefig(direc + name + ext_eP, format='pdf',bbox_inches="tight", pad_inches = 0.3)


################################################################
#CLUSTERING + WEAK LENSING + CROSS
################################################################
#Giving the name of the survey "name" and the bias names "bias_names", this function loads the Fisher matrices for the combination of clustering and lensing 
# and the inputs of the survey, then it computes the errors and generates the tables.

def table_generator_clust_lens( name, bias_names ):
    direc_mi = './Results/Clustering_lensing_cross/' + name + '/Model_independent/Fisher_matrices/'
    direc_chv = './Results/Clustering_lensing_cross/' + name + '/Change_variable/Fisher_matrices/'

    exten_clust_p_A_R_E = '_Fisher_clust_p_A_R_E.out'
    exten_lens_p_E_L = '_Fisher_lens_p_E_L.out'
    exten_tot_p_A_R_L_E = '_Fisher_tot_p_A_R_L_E.out'

    direc_clust_p_A_R_E = direc_mi + name + exten_clust_p_A_R_E
    direc_lens_p_E_L = direc_mi + name + exten_lens_p_E_L
    direc_tot_p_A_R_L_E = direc_mi + name + exten_tot_p_A_R_L_E

    F_clust_p_A_R_E = np.loadtxt(direc_clust_p_A_R_E)
    F_lens_p_E_L = np.loadtxt(direc_lens_p_E_L)
    F_tot_p_A_R_L_E = np.loadtxt(direc_tot_p_A_R_L_E)

    exten_clust_b_f_E = '_Fisher_clust_b_f_E.out'
    exten_tot_b_f_Sigma_E = '_Fisher_tot_b_f_Sigma_E.out'

    direc_clust_b_f_E = direc_chv + name + exten_clust_b_f_E
    direc_tot_b_f_Sigma_E = direc_chv + name + exten_tot_b_f_Sigma_E

    F_clust_b_f_E = np.loadtxt(direc_clust_b_f_E)
    F_tot_b_f_Sigma_E = np.loadtxt(direc_tot_b_f_Sigma_E)

    z, zb, lnk, lnkb, dzC, dzL, nb, b, nt, zm, fsky, S0, gint, Omegam, gamma, h, omegab, ns, s8, arr = imp.Data_survey_clust_lens( name )

    F_clust_A_R_E, k, P0, DP0_clust = P_k_errors(F_clust_p_A_R_E, lnk, lnkb, arr )
    F_lens_E_L, k, P0, DP0_lens = P_k_errors(F_lens_p_E_L, lnk, lnkb, arr )
    F_tot_A_R_L_E, k, P0, DP0_tot = P_k_errors(F_tot_p_A_R_L_E, lnk, lnkb, arr )

    A = fun.A_z( z, b, Omegam, gamma, s8 )
    R = fun.R_z( z, Omegam, gamma, s8 )
    E = fun.E_z( z, Omegam )
    f = fun.f_z( z, Omegam, gamma )
    L = fun.L_z( z, Omegam, gamma, s8 )
    Sigma = np.ones(np.size(z))

    dA_clust = np.zeros(np.size(A))
    dA_clust.shape = A.shape
    dA_tot = np.zeros(np.size(A))
    dA_tot.shape = A.shape

    db_clust = np.zeros(np.size(b))
    db_clust.shape = b.shape
    db_tot = np.zeros(np.size(b))
    db_tot.shape = b.shape

    dR_clust = np.zeros(np.size(R))
    dR_tot = np.zeros(np.size(R))

    df_clust = np.zeros(np.size(f))
    df_tot = np.zeros(np.size(f))

    dL_lens = np.zeros(np.size(L))
    dL_tot = np.zeros(np.size(L))

    dSigma_tot = np.zeros(np.size(L))

    dE_clust = np.zeros(np.size(E))
    dE_lens = np.zeros(np.size(E))
    dE_tot = np.zeros(np.size(E))

    F_clust_A_R_E_inv = np.linalg.inv(F_clust_A_R_E)
    F_lens_E_L_inv = np.linalg.inv(F_lens_E_L)
    F_tot_A_R_L_E_inv = np.linalg.inv(F_tot_A_R_L_E)

    F_clust_b_f_E_inv = np.linalg.inv(F_clust_b_f_E)
    F_tot_b_f_Sigma_E_inv = np.linalg.inv(F_tot_b_f_Sigma_E)

    b_size = np.size(b)/np.size(z)
    for i in np.arange(0,np.size(z)):
	for j in np.arange(0,b_size):
	    dA_clust[j][i] = np.sqrt(F_clust_A_R_E_inv[(b_size+2)*i+j][(b_size+2)*i+j])
	    dA_tot[j][i] = np.sqrt(F_tot_A_R_L_E_inv[(b_size+3)*i+j][(b_size+3)*i+j])
	    db_clust[j][i] = np.sqrt(F_clust_b_f_E_inv[(b_size+2)*i+j][(b_size+2)*i+j])
	    db_tot[j][i] = np.sqrt(F_tot_b_f_Sigma_E_inv[(b_size+3)*i+j][(b_size+3)*i+j])

	dR_clust[i] = np.sqrt(F_clust_A_R_E_inv[(b_size+2)*i+b_size][(b_size+2)*i+b_size])
	dR_tot[i] = np.sqrt(F_tot_A_R_L_E_inv[(b_size+3)*i+b_size][(b_size+3)*i+b_size])
	df_clust[i] = np.sqrt(F_clust_b_f_E_inv[(b_size+2)*i+b_size][(b_size+2)*i+b_size])
	df_tot[i] = np.sqrt(F_tot_b_f_Sigma_E_inv[(b_size+3)*i+b_size][(b_size+3)*i+b_size])
	dL_lens[i] = np.sqrt(F_lens_E_L_inv[2*i+1][2*i+1])
	dL_tot[i] = np.sqrt(F_tot_A_R_L_E_inv[(b_size+3)*i+b_size+1][(b_size+3)*i+b_size+1])
	dSigma_tot[i] = np.sqrt(F_tot_b_f_Sigma_E_inv[(b_size+3)*i+b_size+1][(b_size+3)*i+b_size+1])
	dE_clust[i] = np.sqrt(F_clust_A_R_E_inv[(b_size+2)*i+b_size+1][(b_size+2)*i+b_size+1])
	dE_lens[i] = np.sqrt(F_lens_E_L_inv[2*i][2*i])
	dE_tot[i] = np.sqrt(F_tot_A_R_L_E_inv[(b_size+3)*i+b_size+2][(b_size+3)*i+b_size+2])

    dAp_clust = 100*(dA_clust/A)
    dAp_tot = 100*(dA_tot/A)

    dbp_clust = 100*(db_clust/b)
    dbp_tot = 100*(db_tot/b)

    dRp_clust = 100*(dR_clust/R)
    dRp_tot = 100*(dR_tot/R)

    dfp_clust = 100*(df_clust/f)
    dfp_tot = 100*(df_tot/f)

    dLp_lens = 100*(dL_lens/L)
    dLp_tot = 100*(dL_tot/L)

    dSigmap_tot = 100*(dSigma_tot/Sigma)

    dEp_clust = 100*(dE_clust/E)
    dEp_lens = 100*(dE_lens/E)
    dEp_tot = 100*(dE_tot/E)

    dPp_clust = 100*(DP0_clust/P0)
    dPp_lens = 100*(DP0_lens/P0)
    dPp_tot = 100*(DP0_tot/P0)

    direc_mi = './Results/Clustering_lensing_cross/' + name + '/Model_independent/Tables/'
    direc_chv = './Results/Clustering_lensing_cross/' + name + '/Change_variable/Tables/'

    hed_A_R_E = ' z'
    hed_b_f_E = ' z'
    for j in np.arange(0,b_size):
        hed_A_R_E = hed_A_R_E + '     A_' + bias_names[j]

    for j in np.arange(0,b_size):
        hed_A_R_E = hed_A_R_E + '     dA_' + bias_names[j]
    
    for j in np.arange(0,b_size):
        hed_A_R_E = hed_A_R_E + '     dA_' + bias_names[j] + '/A_' + bias_names[j] + ' (%)'

    for j in np.arange(0,b_size):
        hed_b_f_E = hed_b_f_E + '     b_' + bias_names[j]

    for j in np.arange(0,b_size):
        hed_b_f_E = hed_b_f_E + '     db_' + bias_names[j]
    
    for j in np.arange(0,b_size):
        hed_b_f_E = hed_b_f_E + '     db_' + bias_names[j] + '/b_' + bias_names[j] + ' (%)'

    hed_clust_A_R_E = hed_A_R_E + '   R   dR   dR/R (%)   E   dE   dE/E (%)   '
    DATA_clust = ((np.concatenate((z,A.reshape(np.size(A)),dA_clust.reshape(np.size(dA_clust)),dAp_clust.reshape(np.size(dAp_clust)),R, dR_clust, dRp_clust, E, dE_clust, dEp_clust))).reshape(1+(2+b_size)*3,np.size(z))).transpose()
    exten_clust_A_R_E = '_errors_clust_A_R_E.out'
    direc_table_clust = direc_mi + name + exten_clust_A_R_E
    np.savetxt(direc_table_clust, DATA_clust, fmt='%1.2e', delimiter='  |  ',header=hed_clust_A_R_E)

    hed_clust_b_f_E = hed_b_f_E + '   f   df   df/f (%)   E   dE   dE/E (%)   '
    DATA_clust = ((np.concatenate((z,b.reshape(np.size(b)),db_clust.reshape(np.size(db_clust)),dbp_clust.reshape(np.size(dbp_clust)), f, df_clust, dfp_clust, E, dE_clust, dEp_clust))).reshape(1+(2+b_size)*3,np.size(z))).transpose()
    exten_clust_b_f_E = '_errors_clust_b_f_E.out'
    direc_table_clust = direc_chv + name + exten_clust_b_f_E
    np.savetxt(direc_table_clust, DATA_clust, fmt='%1.2e', delimiter='  |  ',header=hed_clust_b_f_E)

    DATA_lens = ((np.concatenate((z, L, dL_lens, dLp_lens, E, dE_lens, dEp_lens))).reshape(7,np.size(z))).transpose()
    exten_lens = '_errors_lens.out'
    direc_table_lens = direc_mi + name + exten_lens
    np.savetxt(direc_table_lens, DATA_lens, fmt='%1.2e', delimiter='  |  ',header=' z   L   dL   dL/L (%)   E   dE   dE/E (%)')

    hed_tot_A_R_E = hed_A_R_E + '    R   dR   dR/R (%)   L   dL   dL/L (%)   E   dE   dE/E (%)   '
    DATA_tot = ((np.concatenate((z,A.reshape(np.size(A)),dA_tot.reshape(np.size(dA_tot)),dAp_tot.reshape(np.size(dAp_tot)),R, dR_tot, dRp_tot, L, dL_tot, dLp_tot, E, dE_tot, dEp_tot))).reshape(1+(3+b_size)*3,np.size(z))).transpose()
    exten_tot_A_R_E = '_errors_tot_A_R_L_E.out'
    direc_table_tot = direc_mi + name + exten_tot_A_R_E
    np.savetxt(direc_table_tot, DATA_tot, fmt='%1.2e', delimiter='  |  ',header=hed_tot_A_R_E)

    hed_tot_b_f_E = hed_b_f_E + '   f   df   df/f (%)   Sigma   dSigma   dSigma/Sigma (%)   E   dE   dE/E (%)   '
    DATA_tot = ((np.concatenate((z,b.reshape(np.size(b)),db_tot.reshape(np.size(db_tot)),dbp_tot.reshape(np.size(dbp_tot)), f, df_tot, dfp_tot, Sigma, dSigma_tot, dSigmap_tot, E, dE_tot, dEp_tot))).reshape(1+(3+b_size)*3,np.size(z))).transpose()
    exten_tot_b_f_E = '_errors_tot_b_f_Sigma_E.out'
    direc_table_tot = direc_chv + name + exten_tot_b_f_E
    np.savetxt(direc_table_tot, DATA_tot, fmt='%1.2e', delimiter='  |  ',header=hed_tot_b_f_E)

    DATA_P = ((np.concatenate((k,P0,DP0_clust,dPp_clust,DP0_lens,dPp_lens,DP0_tot,dPp_tot))).reshape(8,np.size(k))).transpose()
    exten = '_errors_P_k.out'
    direc_table = direc_mi + name + exten
    np.savetxt(direc_table, DATA_P, fmt='%1.2e', delimiter='  |  ',header=' k    P    dP_clust    dP/P_clust (%)    dP_lens    dP/P_lens (%)    dP_tot    dP/P_tot (%)')
    
    return z, k, P0, DP0_clust, DP0_lens, DP0_tot, dPp_clust, dPp_lens, dPp_tot, A, dA_clust, dAp_clust, dA_tot, dAp_tot, b, db_clust, dbp_clust, db_tot, dbp_tot, R, dR_clust, dRp_clust, dR_tot, dRp_tot, f, df_clust, dfp_clust, df_tot, dfp_tot, L, dL_lens, dLp_lens, dL_tot, dLp_tot, Sigma, dSigma_tot, dSigmap_tot, E, dE_clust, dEp_clust, dE_lens, dEp_lens, dE_tot, dEp_tot              

#Giving the name of the survey "name" and the bias names "bias_names", computes the errors and tables for the combination of clustering and lensing and makes the plots.

def plot_generator_clust_lens( name, bias_names ):
    direc_mi = './Results/Clustering_lensing_cross/' + name + '/Model_independent/Plots/'
    direc_chv = './Results/Clustering_lensing_cross/' + name + '/Change_variable/Plots/'
    z, k, P0, DP0_clust, DP0_lens, DP0_tot, dPp_clust, dPp_lens, dPp_tot, A, dA_clust, dAp_clust, dA_tot, dAp_tot, b, db_clust, dbp_clust, db_tot, dbp_tot, R, dR_clust, dRp_clust, dR_tot, dRp_tot, f, df_clust, dfp_clust, df_tot, dfp_tot, L, dL_lens, dLp_lens, dL_tot, dLp_tot, Sigma, dSigma_tot, dSigmap_tot, E, dE_clust, dEp_clust, dE_lens, dEp_lens, dE_tot, dEp_tot = table_generator_clust_lens( name, bias_names )              
    b_size = np.size(b)/np.size(z)
    for j in np.arange(0,b_size):
        fig = plt.figure()
        b_plot_clust = plt.semilogy(z,dbp_clust[j], color="blue", linewidth=1.5, linestyle="--", label='Clustering')
        b_plot_tot = plt.semilogy(z,dbp_tot[j], color="black", linewidth=2., linestyle="-", label='Total')
        if np.amax(dbp_tot[j]) > 100.:
            plt.ylim(np.amin(dbp_tot[j])/2.,100)

        plt.xlabel("z", fontsize = 20)
        plt.legend()
        labely = "$\Delta \, b_{" + bias_names[j] + "} \, / \, b_{" + bias_names[j] + "}$ (%)"
        plt.ylabel(labely, fontsize = 20)
        ext_b = '_err_b_' + bias_names[j] + '.pdf'
        plt.savefig(direc_chv + name + ext_b, format='pdf',bbox_inches="tight", pad_inches = 0.3)
        fig = plt.figure()
        A_plot_clust = plt.semilogy(z,dAp_clust[j], color="blue", linewidth=1.5, linestyle="--", label='Clustering')
        A_plot_tot = plt.semilogy(z,dAp_tot[j], color="black", linewidth=2., linestyle="-", label='Total')
        if np.amax(dAp_tot[j]) > 100.:
            plt.ylim(np.amin(dAp_tot[j])/2.,100)

        plt.xlabel("z", fontsize = 20)
        plt.legend()
        labely = "$\Delta \, A_{" + bias_names[j] + "} \, / \, A_{" + bias_names[j] + "}$ (%)"
        plt.ylabel(labely, fontsize = 20)
        ext_A = '_err_A_' + bias_names[j] + '.pdf'
        plt.savefig(direc_mi + name + ext_A, format='pdf',bbox_inches="tight", pad_inches = 0.3)

    fig = plt.figure()
    R_plot_clust = plt.semilogy(z,dRp_clust, color="blue", linewidth=1.5, linestyle="--", label='Clustering')
    R_plot_tot = plt.semilogy(z,dRp_tot, color="black", linewidth=2., linestyle="-", label='Total')
    plt.xlabel("z", fontsize = 20)
    plt.ylabel("$\Delta \, R \, / \, R$ (%)", fontsize = 20)
    plt.legend()
    ext_R = '_err_R.pdf'
    plt.savefig(direc_mi + name + ext_R, format='pdf',bbox_inches="tight", pad_inches = 0.3)

    fig = plt.figure()
    f_plot_clust = plt.semilogy(z,dfp_clust, color="blue", linewidth=1.5, linestyle="--", label='Clustering')
    f_plot_tot = plt.semilogy(z,dfp_tot, color="black", linewidth=2., linestyle="-", label='Total')
    plt.xlabel("z", fontsize = 20)
    plt.ylabel("$\Delta \, f \, / \, f$ (%)", fontsize = 20)
    plt.legend()
    ext_f = '_err_f.pdf'
    plt.savefig(direc_chv + name + ext_f, format='pdf',bbox_inches="tight", pad_inches = 0.3)

    fig = plt.figure()
    L_plot_lens = plt.semilogy(z,dLp_lens, color="orange", linewidth=1.5, linestyle="-.", label='Lensing')
    L_plot_tot = plt.semilogy(z,dLp_tot, color="black", linewidth=2., linestyle="-", label='Total')
    plt.xlabel("z", fontsize = 20)
    plt.ylabel("$\Delta \, L \, / \, L$ (%)", fontsize = 20)
    plt.legend()
    ext_L = '_err_L.pdf'
    plt.savefig(direc_mi + name + ext_L, format='pdf',bbox_inches="tight", pad_inches = 0.3)

    fig = plt.figure()
    Sigma_plot_tot = plt.semilogy(z,dSigmap_tot, color="black", linewidth=2., linestyle="-", label='Total')
    plt.xlabel("z", fontsize = 20)
    plt.ylabel("$\Delta \, \Sigma \, / \, \Sigma$ (%)", fontsize = 20)
    plt.legend()
    ext_Sigma = '_err_Sigma.pdf'
    plt.savefig(direc_chv + name + ext_Sigma, format='pdf',bbox_inches="tight", pad_inches = 0.3)

    fig = plt.figure()
    E_plot_clust = plt.semilogy(z,dEp_clust, color="blue", linewidth=1.5, linestyle="--", label='Clustering')
    E_plot_lens = plt.semilogy(z,dEp_lens, color="orange", linewidth=1.5, linestyle="-.", label='Lensing')
    E_plot_tot = plt.semilogy(z,dEp_tot, color="black", linewidth=2., linestyle="-", label='Total')
    plt.xlabel("z", fontsize = 20)
    plt.ylabel("$\Delta \, E \, / \, E$ (%)", fontsize = 20)
    plt.legend()
    ext_E = '_err_E.pdf'
    plt.savefig(direc_mi + name + ext_E, format='pdf',bbox_inches="tight", pad_inches = 0.3)

    fig = plt.figure()
    P_plot_clust = plt.loglog(k,dPp_clust, color="blue", linewidth=1.5, linestyle="--", label='Clustering')
    P_plot_lens = plt.loglog(k,dPp_lens, color="orange", linewidth=1.5, linestyle="-.", label='Lensing')
    P_plot_tot = plt.loglog(k,dPp_tot, color="black", linewidth=2., linestyle="-", label='Total')
    plt.xlabel("k $(h/Mpc)$", fontsize = 20)
    plt.ylabel("$\Delta \, \hat{P} \, / \, \hat{P}$ (%)", fontsize = 20)
    plt.legend()
    ext_eP = '_err_P.pdf'
    plt.savefig(direc_mi + name + ext_eP, format='pdf',bbox_inches="tight", pad_inches = 0.3)
