# coding=utf-8

import numpy as np
import Modules.Change_control.Control as con
import Modules.Plot_table_gen as plo
import Input_file as inp
import os
import shutil

name, do, Omegam, gamma, h, omegab, ns, s8, arr, z, zb, lnk, lnkb, fsky, S0, b, nb, dzC, bias_names, gint, dzL, nt, zm = inp.Inp_dat()

if do=='C':

	F_clust = con.Clustering_only( z, zb, lnk, lnkb, dzC, nb, b, fsky, S0, Omegam, gamma, s8, arr )

	rut = './Results/Clustering_only/' + name
	if os.path.isdir(rut):
	    shutil.rmtree(rut)

	os.makedirs(rut)

        rut_Model_independent = './Results/Clustering_only/' + name + '/Model_independent'
	rut_Change_variable = './Results/Clustering_only/' + name + '/Change_variable'
  
        os.makedirs(rut_Model_independent)
	os.makedirs(rut_Change_variable)
    
	rut_Fisher = './Results/Clustering_only/' + name + '/Model_independent/Fisher_matrices'
	rut_plots = './Results/Clustering_only/' + name + '/Model_independent/Plots'
	rut_tables = './Results/Clustering_only/' + name + '/Model_independent/Tables'
	rut_data = './Results/Clustering_only/' + name + '/Model_independent/Data_survey'

	os.makedirs(rut_Fisher)
	os.makedirs(rut_plots)
	os.makedirs(rut_tables)
	os.makedirs(rut_data)

        rut_Fisher = './Results/Clustering_only/' + name + '/Change_variable/Fisher_matrices'
	rut_plots = './Results/Clustering_only/' + name + '/Change_variable/Plots'
	rut_tables = './Results/Clustering_only/' + name + '/Change_variable/Tables'
	rut_data = './Results/Clustering_only/' + name + '/Change_variable/Data_survey'

	os.makedirs(rut_Fisher)
	os.makedirs(rut_plots)
	os.makedirs(rut_tables)
	os.makedirs(rut_data)

	direc_mi = './Results/Clustering_only/' + name + '/Model_independent/Fisher_matrices/'
	direc_chv = './Results/Clustering_only/' + name + '/Change_variable/Fisher_matrices/'
	exten_p_A_R_E = '_Fisher_p_A_R_E.out'

	direc_p_A_R_E = direc_mi + name + exten_p_A_R_E

	np.savetxt(direc_p_A_R_E, F_clust)

	F_clust_b_f = con.Clustering_change( F_clust, z, zb, b, Omegam, gamma, s8 )

	exten_b_f_E = '_Fisher_b_f_E.out'

	direc_b_f_E = direc_chv + name + exten_b_f_E

	np.savetxt(direc_b_f_E, F_clust_b_f)

	######################################################################################
	######################################################################################

	direc_data_mi = './Results/Clustering_only/' + name + '/Model_independent/Data_survey/'
        direc_data_chv = './Results/Clustering_only/' + name + '/Change_variable/Data_survey/'
	exten_data = '_data.npz'

	direc_data_mi = direc_data_mi + name + exten_data
        direc_data_chv = direc_data_chv + name + exten_data

	Fiducial = np.array([Omegam, gamma, h, omegab, ns, s8])

	np.savez_compressed(direc_data_mi, Fiducial=Fiducial, arr=arr, S0=S0, z=z, zb=zb, lnk=lnk, lnkb=lnkb, b=b, nb=nb, dzC=dzC, fsky=fsky )
        np.savez_compressed(direc_data_chv, Fiducial=Fiducial, arr=arr, S0=S0, z=z, zb=zb, lnk=lnk, lnkb=lnkb, b=b, nb=nb, dzC=dzC, fsky=fsky )

	######################################################################################
	######################################################################################

	plo.plot_generator_clust( name, bias_names )

elif do=='L':

	F_lens = con.Lensing_only( fsky, z, zb, lnk, lnkb, dzL, zm, nt, gint, Omegam, gamma, s8, arr )

	rut = './Results/Weak_lensing_only/' + name
	if os.path.isdir(rut):
	    shutil.rmtree(rut)

	os.makedirs(rut)

	rut_Fisher = './Results/Weak_lensing_only/' + name + '/Fisher_matrices'
	rut_plots = './Results/Weak_lensing_only/' + name + '/Plots'
	rut_tables = './Results/Weak_lensing_only/' + name + '/Tables'
	rut_data = './Results/Weak_lensing_only/' + name + '/Data_survey'

	os.makedirs(rut_Fisher)
	os.makedirs(rut_plots)
	os.makedirs(rut_tables)
	os.makedirs(rut_data)

	direc = './Results/Weak_lensing_only/' + name + '/Fisher_matrices/'
	exten_p_E_L = '_Fisher_p_E_L.out'

	direc_p_E_L = direc + name + exten_p_E_L

	np.savetxt(direc_p_E_L, F_lens)

	######################################################################################
	######################################################################################

	direc_data = './Results/Weak_lensing_only/'  + name + '/Data_survey/'
	exten_data = '_data.npz'

	direc_data = direc_data + name + exten_data

	Fiducial = np.array([Omegam, gamma, h, omegab, ns, s8])

	np.savez_compressed(direc_data, Fiducial=Fiducial, arr=arr, gint=gint, z=z, zb=zb, lnk=lnk, lnkb=lnkb, dzL=dzL, nt=nt, zm=zm, fsky=fsky )

	######################################################################################
	######################################################################################

	plo.plot_generator_lens( name )

elif do=='C_L_C':

	F_tot, F_clust, F_lens = con.Clust_lens_cross( fsky, z, zb, lnk, lnkb, dzL, dzC, zm, nt, nb, b, gint, S0, Omegam, gamma, s8, arr )

	rut = './Results/Clustering_lensing_cross/' + name
	if os.path.isdir(rut):
	    shutil.rmtree(rut)

	os.makedirs(rut)

        rut_Model_independent = './Results/Clustering_lensing_cross/' + name + '/Model_independent'
	rut_Change_variable = './Results/Clustering_lensing_cross/' + name + '/Change_variable'
  
        os.makedirs(rut_Model_independent)
	os.makedirs(rut_Change_variable)
    
	rut_Fisher = './Results/Clustering_lensing_cross/' + name + '/Model_independent/Fisher_matrices'
	rut_plots = './Results/Clustering_lensing_cross/' + name + '/Model_independent/Plots'
	rut_tables = './Results/Clustering_lensing_cross/' + name + '/Model_independent/Tables'
	rut_data = './Results/Clustering_lensing_cross/' + name + '/Model_independent/Data_survey'

	os.makedirs(rut_Fisher)
	os.makedirs(rut_plots)
	os.makedirs(rut_tables)
	os.makedirs(rut_data)

        rut_Fisher = './Results/Clustering_lensing_cross/' + name + '/Change_variable/Fisher_matrices'
	rut_plots = './Results/Clustering_lensing_cross/' + name + '/Change_variable/Plots'
	rut_tables = './Results/Clustering_lensing_cross/' + name + '/Change_variable/Tables'
	rut_data = './Results/Clustering_lensing_cross/' + name + '/Change_variable/Data_survey'

	os.makedirs(rut_Fisher)
	os.makedirs(rut_plots)
	os.makedirs(rut_tables)
	os.makedirs(rut_data)

	direc_mi = './Results/Clustering_lensing_cross/' + name + '/Model_independent/Fisher_matrices/'
	direc_chv = './Results/Clustering_lensing_cross/' + name + '/Change_variable/Fisher_matrices/'
	exten_clust_p_A_R_E = '_Fisher_clust_p_A_R_E.out'
	exten_lens_p_E_L = '_Fisher_lens_p_E_L.out'
	exten_tot_p_A_R_L_E = '_Fisher_tot_p_A_R_L_E.out'

	direc_clust_p_A_R_E = direc_mi + name + exten_clust_p_A_R_E
	direc_lens_p_E_L = direc_mi + name + exten_lens_p_E_L
	direc_tot_p_A_R_L_E = direc_mi + name + exten_tot_p_A_R_L_E

	np.savetxt(direc_clust_p_A_R_E, F_clust)
	np.savetxt(direc_lens_p_E_L, F_lens)
	np.savetxt(direc_tot_p_A_R_L_E, F_tot)

	F_clust_b_f = con.Clustering_change( F_clust, z, zb, b, Omegam, gamma, s8 )
	F_tot_b_f_Sigma = con.Clust_lens_cross_change( F_tot, z, zb, b, Omegam, gamma, s8 )

	exten_clust_b_f_E = '_Fisher_clust_b_f_E.out'
	exten_tot_b_f_Sigma_E = '_Fisher_tot_b_f_Sigma_E.out'

	direc_clust_b_f_E = direc_chv + name + exten_clust_b_f_E
	direc_tot_b_f_Sigma_E = direc_chv + name + exten_tot_b_f_Sigma_E

	np.savetxt(direc_clust_b_f_E, F_clust_b_f)
	np.savetxt(direc_tot_b_f_Sigma_E, F_tot_b_f_Sigma)

	######################################################################################
	######################################################################################

        direc_data_mi = './Results/Clustering_lensing_cross/' + name + '/Model_independent/Data_survey/'
        direc_data_chv = './Results/Clustering_lensing_cross/' + name + '/Change_variable/Data_survey/'
	exten_data = '_data.npz'

	direc_data_mi = direc_data_mi + name + exten_data
        direc_data_chv = direc_data_chv + name + exten_data

	Fiducial = np.array([Omegam, gamma, h, omegab, ns, s8])

	np.savez_compressed(direc_data_mi, Fiducial=Fiducial, arr=arr, S0=S0, gint=gint, z=z, zb=zb, lnk=lnk, lnkb=lnkb, b=b, nb=nb, dzC=dzC, dzL=dzL, nt=nt, zm=zm, fsky=fsky )
        np.savez_compressed(direc_data_chv, Fiducial=Fiducial, arr=arr, S0=S0, gint=gint, z=z, zb=zb, lnk=lnk, lnkb=lnkb, b=b, nb=nb, dzC=dzC, dzL=dzL, nt=nt, zm=zm, fsky=fsky )

	######################################################################################
	######################################################################################

	plo.plot_generator_clust_lens( name, bias_names )
